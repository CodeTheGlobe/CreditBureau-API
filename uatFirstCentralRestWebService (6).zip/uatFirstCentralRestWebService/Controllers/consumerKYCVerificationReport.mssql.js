// const mssql = require('mssql');
// const mssqlcon = require("../Config");


// let storedProc = 'Reports_Consumer_SubjectsList';
// let storedProc2 = 'Reports_Consumer_PersonalDetailsSummary';
// let storedProc3 = 'Reports_Consumer_AddressHistoryTop';
// const storedProc4 = 'sp_i_SubscriberEnquiryResultWeb';

const RealProductID = 66;

class matchMssql {
    async consumerKYCVerificationReport(req, res, decodedObj) {

        // const conn = await mssqlcon.getConnection();


            // const SubscriberEnquiryEngineID = req.subscriberenquiryengineid;
            const Identification = req.identification;
            let recordsets = [];
            //console.log(req);
            
if(Identification=='22471069115')
{
    {
             recordsets = [
                
                    {
                         //Hardcoded demo report
                        "SubjectList": [
                            {
                                "ConsumerID": "2599049",
                                "SearchOutput": "Amos, Testi, , College Road Abaro Aladje",
                                "Reference": "2599049"
                            }
                        ]
                    },
                    {
                        "PersonalDetailsSummary": [
                            {
                                "ConsumerID": "2599049",
                                "Header": "PERSONAL DETAILS SUMMARY: Amos Testi ",
                                "ReferenceNo": null,
                                "Nationality": "Nigeria",
                                "NationalIDNo": "",
                                "PassportNo": null,
                                "DriversLicenseNo": null,
                                "BankVerificationNo": "22471069115",
                                "PencomIDNo": "",
                                "OtheridNo": "",
                                "BirthDate": "26/01/1977",
                                "Dependants": "0",
                                "Gender": "Female",
                                "MaritalStatus": null,
                                "ResidentialAddress1": "College Road Abaro Aladje",
                                "ResidentialAddress2": "Delta",
                                "ResidentialAddress3": "",
                                "ResidentialAddress4": " ",
                                "PostalAddress1": null,
                                "PostalAddress2": null,
                                "PostalAddress3": null,
                                "PostalAddress4": null,
                                "HomeTelephoneNo": null,
                                "WorkTelephoneNo": null,
                                "CellularNo": "",
                                "EmailAddress": "",
                                "EmployerDetail": null,
                                "PropertyOwnedType": "",
                                "Surname": "Amos",
                                "FirstName": "Testi",
                                "OtherNames": ""
                            }
                        ]
                    },
                    {
                        "IdentificationHistory": [
                            {
                                "UpDateDate": null,
                                "UpDateOnDate": null,
                                "IdentificationNumber": null,
                                "IdentificationType": null
                            }
                        ]
                    },
                    {
                        "AddressHistory": [
                            {
                                "UpDateDate": "30/11/2020",
                                "UpDateOnDate": "30/11/2020",
                                "Address1": "College Road Abaro Aladje",
                                "Address2": null,
                                "Address3": "Warri",
                                "Address4": "Delta",
                                "AddressTypeInd": "Residential"
                            },
                            {
                                "UpDateDate": "29/09/2020",
                                "UpDateOnDate": "29/09/2020",
                                "Address1": "College Road Abaro Aladje",
                                "Address2": null,
                                "Address3": "Warri",
                                "Address4": "Delta",
                                "AddressTypeInd": "Residential"
                            },
                            {
                                "UpDateDate": "29/03/2021",
                                "UpDateOnDate": "29/03/2021",
                                "Address1": "College Road Abaro Aladje",
                                "Address2": "Warri",
                                "Address3": "Delta",
                                "Address4": null,
                                "AddressTypeInd": "Residential"
                            },
                            {
                                "UpDateDate": "25/06/2021",
                                "UpDateOnDate": "25/06/2021",
                                "Address1": "College Road Abaro Aladje",
                                "Address2": "Delta",
                                "Address3": null,
                                "Address4": null,
                                "AddressTypeInd": "Residential"
                            },
                            {
                                "UpDateDate": "21/08/2020",
                                "UpDateOnDate": "21/08/2020",
                                "Address1": "College Road Abaro Aladje",
                                "Address2": null,
                                "Address3": "Warri",
                                "Address4": "Delta",
                                "AddressTypeInd": "Residential"
                            }
                        ]
                    },
                    {
                        "EmploymentHistory": [
                            {
                                "UpDateDate": null,
                                "UpDateOnDate": null,
                                "EmployerDetail": null,
                                "Occupation": null
                            }
                        ]
                    },
                    {
                        "TelephoneHistory": [
                            {
                                "HomeNoUpdatedonDate": null,
                                "HomeTelephoneNumber": null,
                                "WorkNoUpdatedonDate": null,
                                "WorkTelephoneNumber": null,
                                "MobileNoUpdatedonDate": null,
                                "MobileTelephoneNumber": null
                            }
                        ]
                    }
                ]
            
    
    }

}
else 
{
return "Customer not found";
}
        return recordsets;

        } 
}

module.exports = new matchMssql();