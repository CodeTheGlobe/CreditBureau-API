// const mssql = require('mssql');
// const mssqlcon = require("../Config");


// const storedProc = 'spCommercial_S_Match_Easy_web';

class matchMssql {
    async commercialmatch(req, res, decodedObj) {

        // const conn = await mssqlcon.getConnection();

     
            
	
            const BusinessName = req.businessname.toLowerCase();
            //console.log(BusinessName);
            const BusinessRegistrationNumber = req.businessregistrationnumber.toLowerCase();
            const AccountNumber = req.accountnumber;
            let recordsets = [];

if(BusinessRegistrationNumber=='rc test02' || BusinessRegistrationNumber=='rctest02' || BusinessRegistrationNumber=='rc test01' || BusinessRegistrationNumber=='rctest01' || BusinessName=='och test dummy' || BusinessName=='och test dummy 5' || BusinessName=='och test dummy 4' || BusinessName=='och test dummy 2' )
{
             recordsets = [
                {
                    "ConnectCommercialMatch": [
                        {
                            "MatchingEngineID": "6171411",
                            "SubscriberEnquiryID": "79398247",
                            "CommercialID": "853535",
                            "BusinessName": "OCH TEST DUMMY 5",
                            "TradingName": null,
                            "RegistrationNo": "",
                            "TaxIDNo": "NIL",
                            "CommencementDate": null,
                            "IncorporationDate": "2018-07-30T00:00:00.000Z",
                            "AccountNo": "1021392523",
                            "TelePhoneNumber": null
                        },
                        {
                            "MatchingEngineID": "6171412",
                            "SubscriberEnquiryID": "79398247",
                            "CommercialID": "853552",
                            "BusinessName": "OCH TEST DUMMY 4",
                            "TradingName": null,
                            "RegistrationNo": "",
                            "TaxIDNo": "NIL",
                            "CommencementDate": null,
                            "IncorporationDate": "2018-07-30T00:00:00.000Z",
                            "AccountNo": "1021392516",
                            "TelePhoneNumber": null
                        },
                        {
                            "MatchingEngineID": "6171413",
                            "SubscriberEnquiryID": "79398247",
                            "CommercialID": "916135",
                            "BusinessName": "OCH TEST DUMMY 2",
                            "TradingName": null,
                            "RegistrationNo": "",
                            "TaxIDNo": "NIL",
                            "CommencementDate": null,
                            "IncorporationDate": "2018-07-30T00:00:00.000Z",
                            "AccountNo": "1021392499",
                            "TelePhoneNumber": null
                        }
                    ]
                }
            ]
 }
   //console.log(recordsets);
            return recordsets;
        } 
}

module.exports = new matchMssql();