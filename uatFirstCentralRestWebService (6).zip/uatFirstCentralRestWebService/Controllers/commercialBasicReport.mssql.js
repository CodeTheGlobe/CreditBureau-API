// const mssql = require('mssql');
// const mssqlcon = require("../Config");


// const storedProc = 'Reports_Commercial_SubjectsList';
// const storedProc2 = 'Reports_Commercial_DetailedBusinessData';
// const storedProc3 = 'Reports_Commercial_CreditAccountSummary';
// const storedProc4 = 'Reports_Commercial_DirectorInformation';
// const storedProc5 = 'sp_i_SubscriberEnquiryResultWeb';


class matchMssql {
    async commercialBasicReport(req, res, decodedObj) {

       

            
            const SubscriberEnquiryEngineID = req.subscriberenquiryengineid;
            const EnquiryID = req.enquiryid;
            const commercialid = req.commercialid;
            const MergeList = req.commercialmergelist;
            let recordsets = [];

            if(EnquiryID=="79398247" && SubscriberEnquiryEngineID=="6171411" || SubscriberEnquiryEngineID=="6171412" || SubscriberEnquiryEngineID=="6171413" && commercialid=="853535" || commercialid=="853552" || commercialid=="916135" && MergeList=="" || MergeList=="853535,853552,916135"  || MergeList=="853535,853552" || MergeList=="853552,916135" || MergeList=="853535,916135"   )

            {
                //Hardcoded demo report
             recordsets = [
                {
                    "SubjectList": [
                        {
                            "CommercialID": "853535",
                            "SearchOutput": "OCH TEST DUMMY 5,  - ",
                            "Reference": "853535"
                        }
                    ]
                },
                {
                    "BusinessData": [
                        {
                            "CommercialID": "853535",
                            "ReferenceNo": null,
                            "BusinessName": "OCH TEST DUMMY 5",
                            "TradingName": null,
                            "IndustrySector": "",
                            "PreviousBusinessName": "",
                            "BusinessRegistrationNumber": "",
                            "PreviousRegistrationNumber": null,
                            "NoOfDirectors": "0",
                            "BusinessType": "",
                            "DateOfIncorporation": "30/07/2018",
                            "DateOfCommencement": null,
                            "TaxIdentificationNumber": "",
                            "VatNumber": null,
                            "Webaddress": null,
                            "CommercialEmail1": null,
                            "CommercialEmail2": null,
                            "CommercialEmail3": null,
                            "CommercialEmail4": null,
                            "CommercialAddress1": "UBA HOUSE 57 MARINA",
                            "CommercialAddress2": "",
                            "CommercialAddress3": "",
                            "CommercialAddress4": "",
                            "postalAddress1": "UBA HOUSE 57 MARINAADD",
                            "postalAddress2": "RESS L",
                            "postalAddress3": "",
                            "postalAddress4": "",
                            "Telephone1": null,
                            "Telephone2": null,
                            "Telephone3": null,
                            "Telephone4": null,
                            "Fax1": null,
                            "Fax2": null,
                            "Fax3": null,
                            "Fax4": null,
                            "UpdatedOn": "05/03/2023"
                        }
                    ]
                },
                {
                    "DirectorInformation": [
                        {
                            "Directorid": null,
                            "DateofBirth": null,
                            "firstName": null,
                            "othernames": null,
                            "surname": null,
                            "Identificationnumber": null,
                            "DirectorAppointmentdate": null
                        }
                    ]
                },
                {
                    "FacilityPerformanceSummary": [
                        {
                            "TotalMonthlyInstalment": "0.00",
                            "TotalOutstandingdebt": "3,557,328.00",
                            "TotalAccountarrear": "1.00",
                            "TotalAccounts": "1",
                            "TotalAccounts1": "0",
                            "Amountarrear": "3,557,328.00",
                            "TotalaccountinGoodcondition": "0",
                            "TotalaccountinBadcondition": "1",
                            "TotalNumberofJudgement": "0",
                            "TotalJudgementAmount": "0",
                            "LastJudgementDate": "",
                            "TotalNumberofDishonoured": "0",
                            "TotalDishonouredAmount": "0.00",
                            "LastBouncedChequesDate": null,
                            "TotalMonthlyInstalment1": "0.00",
                            "TotalOutstandingdebt1": "0.00",
                            "TotalAccountarrear1": "0.00",
                            "Amountarrear1": "0.00",
                            "TotalaccountinGoodcondition1": "0",
                            "TotalaccountinBadcondition1": "0",
                            "TotalNumberofJudgement1": "0",
                            "TotalJudgementAmount1": "0",
                            "LastJudgementDate1": "",
                            "TotalNumberofDishonoured1": "0",
                            "TotalDishonouredAmount1": "0.00",
                            "LastBouncedChequesDate1": null,
                            "TotalNumberofAccounts": "1",
                            "LastDishonouredChequeDate": "0",
                            "Rating": "999"
                        }
                    ]
                },
                {
                    "HighestDelinquencyRating": [
                        {
                            "HighestDelinquencyRating": "10"
                        }
                    ]
                },
                {
                    "EnquiryDetails": [
                        {
                            "SubscriberEnquiryResultID": "22080301",
                            "ProductID": 46,
                            "MatchingRate": 87,
                            "SubscriberEnquiryEngineID": "179523242"
                        }
                    ]
                }
            ];

        }
        else {
             recordsets = ["invalid payload"];
         }
        //  console.log(recordsets);
            return recordsets;
        

    }
   
}

module.exports = new matchMssql();