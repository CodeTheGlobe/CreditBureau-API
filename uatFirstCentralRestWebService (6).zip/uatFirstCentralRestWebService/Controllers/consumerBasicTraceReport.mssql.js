


class matchMssql {
    async ConsumerBasicTraceReport(req, res, decodedObj) {
        const RealProductID = 50;
        const EnquiryInput = [];
        const Report = 'Xscore Consumer Basic Trace';
        // const conn = await mssqlcon.getConnection();


            const SubscriberEnquiryEngineID = req.subscriberenquiryengineid;
            const EnquiryID = req.enquiryid;
            const ConsumerID = req.consumerid;
            const MergeList = req.consumermergelist;
            let recordsets = [];

            
if(SubscriberEnquiryEngineID=='179064971' && EnquiryID=='60365700' && ConsumerID=='2599049')
{
        //Hardcoded demo report
             recordsets = [
                {
                    "SubjectList": [
                        {
                            "ConsumerID": "2599049",
                            "SearchOutput": "Amos, Testi, , College Road Abaro Aladje",
                            "Reference": "2599049"
                        }
                    ]
                },
                {
                    "PersonalDetailsSummary": [
                        {
                            "ConsumerID": "2599049",
                            "Header": "PERSONAL DETAILS SUMMARY: Amos Testi ",
                            "ReferenceNo": null,
                            "Nationality": "Nigeria",
                            "NationalIDNo": "",
                            "PassportNo": null,
                            "DriversLicenseNo": null,
                            "BankVerificationNo": "22471069115",
                            "PencomIDNo": "",
                            "OtheridNo": "",
                            "BirthDate": "26/01/1977",
                            "Dependants": "0",
                            "Gender": "Female",
                            "MaritalStatus": null,
                            "ResidentialAddress1": "College Road Abaro Aladje",
                            "ResidentialAddress2": "Delta",
                            "ResidentialAddress3": "",
                            "ResidentialAddress4": " ",
                            "PostalAddress1": null,
                            "PostalAddress2": null,
                            "PostalAddress3": null,
                            "PostalAddress4": null,
                            "HomeTelephoneNo": null,
                            "WorkTelephoneNo": null,
                            "CellularNo": "",
                            "EmailAddress": "",
                            "EmployerDetail": null,
                            "PropertyOwnedType": "",
                            "Surname": "Amos",
                            "FirstName": "Testi",
                            "OtherNames": ""
                        }
                    ]
                },
                {
                    "CreditAccountSummary": [
                        {
                            "TotalMonthlyInstalment": "17,205.00",
                            "TotalOutstandingdebt": "0.00",
                            "TotalAccountarrear": "2",
                            "Amountarrear": "0.00",
                            "TotalAccounts": "7",
                            "TotalAccounts1": "0",
                            "TotalaccountinGodcondition": "6",
                            "TotalaccountinGoodcondition": "6",
                            "TotalNumberofJudgement": "0",
                            "TotalJudgementAmount": "0",
                            "LastJudgementDate": "-",
                            "TotalNumberofDishonoured": "0",
                            "TotalDishonouredAmount": "0.00",
                            "LastBouncedChequesDate": null,
                            "TotalMonthlyInstalment1": "0.00",
                            "TotalOutstandingdebt1": "0.00",
                            "TotalAccountarrear1": "0",
                            "Amountarrear1": "0.00",
                            "TotalaccountinGodcondition1": "1",
                            "TotalaccountinBadcondition": "1",
                            "TotalNumberofJudgement1": "0",
                            "TotalJudgementAmount1": "0",
                            "LastJudgementDate1": "-",
                            "TotalNumberofDishonoured1": "0",
                            "TotalDishonouredAmount1": "0.00",
                            "LastBouncedChequesDate1": null,
                            "Rating": "118"
                        }
                    ]
                },
                {
                    "AccountRating": [
                        {
                            "NoOfHomeLoanAccountsGood": "0",
                            "NoOfHomeLoanAccountsBad": "0",
                            "NoOfAutoLoanccountsGood": "0",
                            "NoOfAutoLoanAccountsBad": "0",
                            "NoOfStudyLoanAccountsGood": "0",
                            "NoOfStudyLoanAccountsBad": "0",
                            "NoOfPersonalLoanAccountsGood": "0",
                            "NoOfPersonalLoanAccountsBad": "0",
                            "NoOfCreditCardAccountsGood": "0",
                            "NoOfCreditCardAccountsBad": "0",
                            "NoOfRetailAccountsGood": "0",
                            "NoOfRetailAccountsBad": "0",
                            "NoOfJointLoanAccountsGood": "0",
                            "NoOfJointLoanAccountsBad": "0",
                            "NoOfTelecomAccountsGood": "0",
                            "NoOfTelecomAccountsBad": "0",
                            "NoOfOtherAccountsGood": "7",
                            "NoOfOtherAccountsBad": "0"
                        }
                    ]
                },
                {
                    "EnquiryDetails": [
                        {
                            "SubscriberEnquiryResultID": null,
                            "ProductID": null,
                            "MatchingRate": null,
                            "SubscriberEnquiryEngineID": null
                        }
                    ]
                }
            ]
 }



     
if(SubscriberEnquiryEngineID=='179065053' && EnquiryID=='60365779' && ConsumerID=='13352613')
{

if(MergeList=='13352613' || MergeList=='')
{
    recordsets = [
        {
            //Hardcoded demo report
            "SubjectList": [
                {
                    "ConsumerID": "13352613",
                    "SearchOutput": "TEST, RUN, TEST, UBNILAWE EKITI",
                    "Reference": "13352613"
                }
            ]
        },
        {
            "PersonalDetailsSummary": [
                {
                    "ConsumerID": "13352613",
                    "Header": "PERSONAL DETAILS SUMMARY: TEST RUN TEST",
                    "ReferenceNo": null,
                    "Nationality": "Nigeria",
                    "NationalIDNo": "",
                    "PassportNo": null,
                    "DriversLicenseNo": null,
                    "BankVerificationNo": "",
                    "PencomIDNo": "",
                    "OtheridNo": "",
                    "BirthDate": "12/12/1950",
                    "Dependants": "0",
                    "Gender": "Female",
                    "MaritalStatus": null,
                    "ResidentialAddress1": "UBNILAWE EKITI",
                    "ResidentialAddress2": "",
                    "ResidentialAddress3": "",
                    "ResidentialAddress4": "13 ",
                    "PostalAddress1": "UBNILAWE EKITI",
                    "PostalAddress2": "",
                    "PostalAddress3": "",
                    "PostalAddress4": "13 ",
                    "HomeTelephoneNo": null,
                    "WorkTelephoneNo": null,
                    "CellularNo": "",
                    "EmailAddress": "",
                    "EmployerDetail": null,
                    "PropertyOwnedType": "",
                    "Surname": "TEST",
                    "FirstName": "RUN",
                    "OtherNames": "TEST"
                }
            ]
        },
        {
            "CreditAccountSummary": [
                {
                    "TotalMonthlyInstalment": "0.00",
                    "TotalOutstandingdebt": "1.00",
                    "TotalAccountarrear": "0",
                    "Amountarrear": "5.00",
                    "TotalAccounts": "1",
                    "TotalAccounts1": "0",
                    "TotalaccountinGodcondition": "1",
                    "TotalaccountinGoodcondition": "1",
                    "TotalNumberofJudgement": "0",
                    "TotalJudgementAmount": "0",
                    "LastJudgementDate": "-",
                    "TotalNumberofDishonoured": "0",
                    "TotalDishonouredAmount": "0.00",
                    "LastBouncedChequesDate": null,
                    "TotalMonthlyInstalment1": "0.00",
                    "TotalOutstandingdebt1": "0.00",
                    "TotalAccountarrear1": "0",
                    "Amountarrear1": "0.00",
                    "TotalaccountinGodcondition1": "0",
                    "TotalaccountinBadcondition": "0",
                    "TotalNumberofJudgement1": "0",
                    "TotalJudgementAmount1": "0",
                    "LastJudgementDate1": "-",
                    "TotalNumberofDishonoured1": "0",
                    "TotalDishonouredAmount1": "0.00",
                    "LastBouncedChequesDate1": null,
                    "Rating": "0"
                }
            ]
        },
        {
            "GuarantorDetails": [
                {
                    "GuarantorsSecured": "0",
                    "Accounts": "0"
                }
            ]
        },
        {
            "GuarantorDetails": [
                {
                    "GuarantorFirstName": "",
                    "GuarantorOtherName": "",
                    "GuarantorNationalIDNo": "",
                    "GuarantorPassport": "",
                    "GuarantorDriverLicenceNo": "",
                    "GuarantorPENCOMIDNo": "",
                    "GuarantorOtherID": "",
                    "GuarantorGender": "",
                    "GuarantorDateOfBirth": "",
                    "GuarantorAddress1": "",
                    "GuarantorAddress2": "",
                    "GuarantorAddress3": "",
                    "GuarantorHomeTelephone": "",
                    "GuarantorworkTelephone": "",
                    "GuarantorMobileTelephone": ""
                }
            ]
        },
        {
            "IdentificationHistory": [
                {
                    "UpDateDate": null,
                    "UpDateOnDate": null,
                    "IdentificationNumber": null,
                    "IdentificationType": null
                }
            ]
        },
        {
            "AddressHistory": [
                {
                    "UpDateDate": "28/10/2014",
                    "UpDateOnDate": "28/10/2014",
                    "Address1": "UBNILAWE EKITI",
                    "Address2": null,
                    "Address3": null,
                    "Address4": "13",
                    "AddressTypeInd": "Residential"
                },
                {
                    "UpDateDate": "28/10/2014",
                    "UpDateOnDate": "28/10/2014",
                    "Address1": "UBNILAWE EKITI",
                    "Address2": null,
                    "Address3": null,
                    "Address4": "13",
                    "AddressTypeInd": "Residential"
                }
            ]
        },
        {
            "EmploymentHistory": [
                {
                    "UpDateDate": null,
                    "UpDateOnDate": null,
                    "EmployerDetail": null,
                    "Occupation": null
                }
            ]
        },
        {
            "TelephoneHistory": []
        }
    ]
 }

 if(MergeList=='13352613,14713314' || MergeList=='14713314,13352613')
{
    recordsets = [
        {
            "SubjectList": [
                {
                    "ConsumerID": "13352613",
                    "SearchOutput": "TEST, RUN, TEST, UBNILAWE EKITI",
                    "Reference": "13352613"
                },
                {
                    "ConsumerID": "14713314",
                    "SearchOutput": "TEST, RUN, , UBNILAWE EKITI",
                    "Reference": "14713314"
                }
            ]
        },
        {
            "PersonalDetailsSummary": [
                {
                    "ConsumerID": "13352613",
                    "Header": "PERSONAL DETAILS SUMMARY: TEST RUN TEST",
                    "ReferenceNo": null,
                    "Nationality": "Nigeria",
                    "NationalIDNo": "",
                    "PassportNo": null,
                    "DriversLicenseNo": null,
                    "BankVerificationNo": "",
                    "PencomIDNo": "",
                    "OtheridNo": "",
                    "BirthDate": "12/12/1950",
                    "Dependants": "0",
                    "Gender": "Female",
                    "MaritalStatus": null,
                    "ResidentialAddress1": "UBNILAWE EKITI",
                    "ResidentialAddress2": "",
                    "ResidentialAddress3": "",
                    "ResidentialAddress4": "13 ",
                    "PostalAddress1": "UBNILAWE EKITI",
                    "PostalAddress2": "",
                    "PostalAddress3": "",
                    "PostalAddress4": "13 ",
                    "HomeTelephoneNo": null,
                    "WorkTelephoneNo": null,
                    "CellularNo": "",
                    "EmailAddress": "",
                    "EmployerDetail": null,
                    "PropertyOwnedType": "",
                    "Surname": "TEST",
                    "FirstName": "RUN",
                    "OtherNames": "TEST"
                }
            ]
        },
        {
            "CreditAccountSummary": [
                {
                    "TotalMonthlyInstalment": "0.00",
                    "TotalOutstandingdebt": "1.00",
                    "TotalAccountarrear": "0",
                    "Amountarrear": "1.00",
                    "TotalAccounts": "2",
                    "TotalAccounts1": "0",
                    "TotalaccountinGodcondition": "1",
                    "TotalaccountinGoodcondition": "1",
                    "TotalNumberofJudgement": "0",
                    "TotalJudgementAmount": "0",
                    "LastJudgementDate": "-",
                    "TotalNumberofDishonoured": "0",
                    "TotalDishonouredAmount": "0.00",
                    "LastBouncedChequesDate": null,
                    "TotalMonthlyInstalment1": "0.00",
                    "TotalOutstandingdebt1": "0.00",
                    "TotalAccountarrear1": "0",
                    "Amountarrear1": "0.00",
                    "TotalaccountinGodcondition1": "0",
                    "TotalaccountinBadcondition": "0",
                    "TotalNumberofJudgement1": "0",
                    "TotalJudgementAmount1": "0",
                    "LastJudgementDate1": "-",
                    "TotalNumberofDishonoured1": "0",
                    "TotalDishonouredAmount1": "0.00",
                    "LastBouncedChequesDate1": null,
                    "Rating": "0"
                }
            ]
        },
        {
            "GuarantorCount": [
                {
                    "GuarantorsSecured": "0",
                    "Accounts": "0"
                }
            ]
        },
        {
            "GuarantorDetails": [
                {
                    "GuarantorFirstName": "",
                    "GuarantorOtherName": "",
                    "GuarantorNationalIDNo": "",
                    "GuarantorPassport": "",
                    "GuarantorDriverLicenceNo": "",
                    "GuarantorPENCOMIDNo": "",
                    "GuarantorOtherID": "",
                    "GuarantorGender": "",
                    "GuarantorDateOfBirth": "",
                    "GuarantorAddress1": "",
                    "GuarantorAddress2": "",
                    "GuarantorAddress3": "",
                    "GuarantorHomeTelephone": "",
                    "GuarantorworkTelephone": "",
                    "GuarantorMobileTelephone": ""
                }
            ]
        },
        {
            "IdentificationHistory": [
                {
                    "UpDateDate": null,
                    "UpDateOnDate": null,
                    "IdentificationNumber": null,
                    "IdentificationType": null
                }
            ]
        },
        {
            "AddressHistory": [
                {
                    "UpDateDate": null,
                    "UpDateOnDate": null,
                    "Address1": null,
                    "Address2": null,
                    "Address3": null,
                    "Address4": null,
                    "AddressTypeInd": null
                }
            ]
        },
        {
            "EmploymentHistory": [
                {
                    "UpDateDate": null,
                    "UpDateOnDate": null,
                    "EmployerDetail": null,
                    "Occupation": null
                }
            ]
        },
        {
            "TelephoneHistory": []
        },
        {
            "EnquiryDetails": [
                {
                    "SubscriberEnquiryResultID": null,
                    "ProductID": null,
                    "MatchingRate": null,
                    "SubscriberEnquiryEngineID": null
                }
            ]
        }
    ]
 }
}

if(SubscriberEnquiryEngineID=='179065053' && EnquiryID=='60365779' && ConsumerID=='14713314')
{

    if(MergeList=='14713314' || MergeList=='')
    {
        recordsets = [
            {
                "SubjectList": [
                    {
                        "ConsumerID": "14713314",
                        "SearchOutput": "TEST, RUN, , UBNILAWE EKITI",
                        "Reference": "14713314"
                    }
                ]
            },
            {
                "PersonalDetailsSummary": [
                    {
                        "ConsumerID": "14713314",
                        "Header": "PERSONAL DETAILS SUMMARY: TEST RUN ",
                        "ReferenceNo": null,
                        "Nationality": "NG",
                        "NationalIDNo": "",
                        "PassportNo": null,
                        "DriversLicenseNo": null,
                        "BankVerificationNo": "",
                        "PencomIDNo": "",
                        "OtheridNo": "",
                        "BirthDate": "12/12/1950",
                        "Dependants": "0",
                        "Gender": "Female",
                        "MaritalStatus": null,
                        "ResidentialAddress1": "UBNILAWE EKITI",
                        "ResidentialAddress2": "",
                        "ResidentialAddress3": "",
                        "ResidentialAddress4": "13 ",
                        "PostalAddress1": "UBNILAWE EKITI",
                        "PostalAddress2": "",
                        "PostalAddress3": "",
                        "PostalAddress4": "13 ",
                        "HomeTelephoneNo": null,
                        "WorkTelephoneNo": null,
                        "CellularNo": "",
                        "EmailAddress": "",
                        "EmployerDetail": null,
                        "PropertyOwnedType": "",
                        "Surname": "TEST",
                        "FirstName": "RUN",
                        "OtherNames": ""
                    }
                ]
            },
            {
                "CreditAccountSummary": [
                    {
                        "TotalMonthlyInstalment": "0.00",
                        "TotalOutstandingdebt": "0.00",
                        "TotalAccountarrear": "0",
                        "Amountarrear": "0.00",
                        "TotalAccounts": "1",
                        "TotalAccounts1": "0",
                        "TotalaccountinGodcondition": "1",
                        "TotalaccountinGoodcondition": "1",
                        "TotalNumberofJudgement": "0",
                        "TotalJudgementAmount": "0",
                        "LastJudgementDate": "-",
                        "TotalNumberofDishonoured": "0",
                        "TotalDishonouredAmount": "0.00",
                        "LastBouncedChequesDate": null,
                        "TotalMonthlyInstalment1": "0.00",
                        "TotalOutstandingdebt1": "0.00",
                        "TotalAccountarrear1": "0",
                        "Amountarrear1": "0.00",
                        "TotalaccountinGodcondition1": "0",
                        "TotalaccountinBadcondition": "0",
                        "TotalNumberofJudgement1": "0",
                        "TotalJudgementAmount1": "0",
                        "LastJudgementDate1": "-",
                        "TotalNumberofDishonoured1": "0",
                        "TotalDishonouredAmount1": "0.00",
                        "LastBouncedChequesDate1": null,
                        "Rating": "0"
                    }
                ]
            },
     
            {
                "GuarantorCount": [
                    {
                        "GuarantorsSecured": "0",
                        "Accounts": "0"
                    }
                ]
            },
            {
                "GuarantorDetails": [
                    {
                        "GuarantorFirstName": "",
                        "GuarantorOtherName": "",
                        "GuarantorNationalIDNo": "",
                        "GuarantorPassport": "",
                        "GuarantorDriverLicenceNo": "",
                        "GuarantorPENCOMIDNo": "",
                        "GuarantorOtherID": "",
                        "GuarantorGender": "",
                        "GuarantorDateOfBirth": "",
                        "GuarantorAddress1": "",
                        "GuarantorAddress2": "",
                        "GuarantorAddress3": "",
                        "GuarantorHomeTelephone": "",
                        "GuarantorworkTelephone": "",
                        "GuarantorMobileTelephone": ""
                    }
                ]
            },
            {
                "EnquiryHistoryTop": [
                    {
                        "SubscriberEnquiryResultID": null,
                        "DateRequested": null,
                        "SubscriberName": null,
                        "EnquiryReason": null,
                        "CompanyTelephoneNo": null
                    }
                ]
            },
            {
                "IdentificationHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "IdentificationNumber": null,
                        "IdentificationType": null
                    }
                ]
            },
            {
                "AddressHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "Address1": null,
                        "Address2": null,
                        "Address3": null,
                        "Address4": null,
                        "AddressTypeInd": null
                    }
                ]
            },
            {
                "EmploymentHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "EmployerDetail": null,
                        "Occupation": null
                    }
                ]
            },
            {
                "TelephoneHistory": []
            },
            {
                "EnquiryDetails": [
                    {
                        "SubscriberEnquiryResultID": null,
                        "ProductID": null,
                        "MatchingRate": null,
                        "SubscriberEnquiryEngineID": null
                    }
                ]
            }
        ]
    }

    if(MergeList=='13352613,14713314' || MergeList=='14713314,13352613')
    {
        recordsets =  [
            {
                "SubjectList": [
                    {
                        "ConsumerID": "13352613",
                        "SearchOutput": "TEST, RUN, TEST, UBNILAWE EKITI",
                        "Reference": "13352613"
                    },
                    {
                        "ConsumerID": "14713314",
                        "SearchOutput": "TEST, RUN, , UBNILAWE EKITI",
                        "Reference": "14713314"
                    }
                ]
            },
            {
                "PersonalDetailsSummary": [
                    {
                        "ConsumerID": "13352613",
                        "Header": "PERSONAL DETAILS SUMMARY: TEST RUN TEST",
                        "ReferenceNo": null,
                        "Nationality": "Nigeria",
                        "NationalIDNo": "",
                        "PassportNo": null,
                        "DriversLicenseNo": null,
                        "BankVerificationNo": "",
                        "PencomIDNo": "",
                        "OtheridNo": "",
                        "BirthDate": "12/12/1950",
                        "Dependants": "0",
                        "Gender": "Female",
                        "MaritalStatus": null,
                        "ResidentialAddress1": "UBNILAWE EKITI",
                        "ResidentialAddress2": "",
                        "ResidentialAddress3": "",
                        "ResidentialAddress4": "13 ",
                        "PostalAddress1": "UBNILAWE EKITI",
                        "PostalAddress2": "",
                        "PostalAddress3": "",
                        "PostalAddress4": "13 ",
                        "HomeTelephoneNo": null,
                        "WorkTelephoneNo": null,
                        "CellularNo": "",
                        "EmailAddress": "",
                        "EmployerDetail": null,
                        "PropertyOwnedType": "",
                        "Surname": "TEST",
                        "FirstName": "RUN",
                        "OtherNames": "TEST"
                    }
                ]
            },
            {
                "CreditAccountSummary": [
                    {
                        "TotalMonthlyInstalment": "0.00",
                        "TotalOutstandingdebt": "1.00",
                        "TotalAccountarrear": "0",
                        "Amountarrear": "1.00",
                        "TotalAccounts": "2",
                        "TotalAccounts1": "0",
                        "TotalaccountinGodcondition": "1",
                        "TotalaccountinGoodcondition": "1",
                        "TotalNumberofJudgement": "0",
                        "TotalJudgementAmount": "0",
                        "LastJudgementDate": "-",
                        "TotalNumberofDishonoured": "0",
                        "TotalDishonouredAmount": "0.00",
                        "LastBouncedChequesDate": null,
                        "TotalMonthlyInstalment1": "0.00",
                        "TotalOutstandingdebt1": "0.00",
                        "TotalAccountarrear1": "0",
                        "Amountarrear1": "0.00",
                        "TotalaccountinGodcondition1": "0",
                        "TotalaccountinBadcondition": "0",
                        "TotalNumberofJudgement1": "0",
                        "TotalJudgementAmount1": "0",
                        "LastJudgementDate1": "-",
                        "TotalNumberofDishonoured1": "0",
                        "TotalDishonouredAmount1": "0.00",
                        "LastBouncedChequesDate1": null,
                        "Rating": "0"
                    }
                ]
            },
            {
                "GuarantorCount": [
                    {
                        "GuarantorsSecured": "0",
                        "Accounts": "0"
                    }
                ]
            },
            {
                "GuarantorDetails": [
                    {
                        "GuarantorFirstName": "",
                        "GuarantorOtherName": "",
                        "GuarantorNationalIDNo": "",
                        "GuarantorPassport": "",
                        "GuarantorDriverLicenceNo": "",
                        "GuarantorPENCOMIDNo": "",
                        "GuarantorOtherID": "",
                        "GuarantorGender": "",
                        "GuarantorDateOfBirth": "",
                        "GuarantorAddress1": "",
                        "GuarantorAddress2": "",
                        "GuarantorAddress3": "",
                        "GuarantorHomeTelephone": "",
                        "GuarantorworkTelephone": "",
                        "GuarantorMobileTelephone": ""
                    }
                ]
            },
            {
                "IdentificationHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "IdentificationNumber": null,
                        "IdentificationType": null
                    }
                ]
            },
            {
                "AddressHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "Address1": null,
                        "Address2": null,
                        "Address3": null,
                        "Address4": null,
                        "AddressTypeInd": null
                    }
                ]
            },
            {
                "EmploymentHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "EmployerDetail": null,
                        "Occupation": null
                    }
                ]
            },
            {
                "TelephoneHistory": []
            },
            {
                "EnquiryDetails": [
                    {
                        "SubscriberEnquiryResultID": null,
                        "ProductID": null,
                        "MatchingRate": null,
                        "SubscriberEnquiryEngineID": null
                    }
                ]
            }
        ]
    
    }

}
        return recordsets;

        }
}

module.exports = new matchMssql();