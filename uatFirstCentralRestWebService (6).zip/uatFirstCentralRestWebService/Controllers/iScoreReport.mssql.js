

class matchMssql {
    async iScoreReport(req, res, decodedObj) {
        const RealProductID = 50;
        const EnquiryInput = [];
        const Report = 'iScore Report';
        // const conn = await mssqlcon.getConnection();

            const SubscriberEnquiryEngineID = req.subscriberenquiryengineid;
            const EnquiryID = req.enquiryid;
            const ConsumerID = req.consumerid;
            const MergeList = req.consumermergelist;
            let recordsets = [];

            
if(SubscriberEnquiryEngineID=='179064971' && EnquiryID=='60365700' && ConsumerID=='2599049')
{
             recordsets = [
                {
                     //Hardcoded demo report
                    "SubjectList": [
                        {
                            "ConsumerID": "2599049",
                            "SearchOutput": "UMORU, MUHAMMED, , PrimaryAddressLine1",
                            "Reference": "2599049"
                        }
                    ]
                },
                {
                    "Scoring": [
                        {
                            "ConsumerID": "2599049",
                            "Surname": "UMORU",
                            "FirstName": "MUHAMMED",
                            "OtherNames": "",
                            "Gender": "Male",
                            "BirthDate": "12/12/1950",
                            "BankVerificationNo": "",
                            "RepaymentHistoryScore": "181/192",
                            "TotalAmountOwedScore": "165/165",
                            "TypesOfCreditScore": "40/55",
                            "LengthOfCreditHistoryScore": "21/83",
                            "NoOfAcctScore": "55/55",
                            "TotalConsumerScore": "762",
                            "Description": "LOW RISK",
                            "ScoreDate": "06/07/2023",
                            "TotalOutstandingDebt": "1.00",
                            "TotalForeignOutstandingDebt": "0.00",
                            "TotalAccountarrear": "0",
                            "TotalAmountOverdue": "5.00",
                            "TotalAccounts": "1",
                            "TotalForeignAccounts": "0",
                            "TotalaccountinGoodcondition": "1",
                            "TotalaccountinBadcondition": "0"
                        }
                    ]
                },
                {
                    "EnquiryDetails": [
                        {
                            "SubscriberEnquiryResultID": null,
                            "ProductID": null,
                            "MatchingRate": null,
                            "SubscriberEnquiryEngineID": null
                        }
                    ]
                }
            ]
 }



     
if(SubscriberEnquiryEngineID=='179065053' && EnquiryID=='60365779' && ConsumerID=='13352613')
{

if(MergeList=='13352613' || MergeList=='')
{
    recordsets = [
        {
             //Hardcoded demo report
            "SubjectList": [
                {
                    "ConsumerID": "13352613",
                    "SearchOutput": "TEST, RUN, TEST, UBNILAWE EKITI",
                    "Reference": "13352613"
                }
            ]
        },
        {
            "Scoring": [
                {
                    "ConsumerID": "13352613",
                    "Surname": "TEST",
                    "FirstName": "RUN",
                    "OtherNames": "TEST",
                    "Gender": "Female",
                    "BirthDate": "12/12/1950",
                    "BankVerificationNo": "",
                    "RepaymentHistoryScore": null,
                    "TotalAmountOwedScore": "0/165",
                    "TypesOfCreditScore": "40/55",
                    "LengthOfCreditHistoryScore": "83/83",
                    "NoOfAcctScore": "11/55",
                    "TotalConsumerScore": null,
                    "Description": null,
                    "ScoreDate": "06/08/2023",
                    "TotalOutstandingDebt": "1.00",
                    "TotalForeignOutstandingDebt": "0.00",
                    "TotalAccountarrear": "0",
                    "TotalAmountOverdue": "5.00",
                    "TotalAccounts": "1",
                    "TotalForeignAccounts": "0",
                    "TotalaccountinGoodcondition": "1",
                    "TotalaccountinBadcondition": "0"
                }
            ]
        },
        {
            "EnquiryDetails": [
                {
                    "SubscriberEnquiryResultID": null,
                    "ProductID": null,
                    "MatchingRate": null,
                    "SubscriberEnquiryEngineID": null
                }
            ]
        }
    ]
 }

 if(MergeList=='13352613,14713314' || MergeList=='14713314,13352613')
{
    recordsets = [
        {
             //Hardcoded demo report
            "SubjectList": [
                {
                    "ConsumerID": "13352613",
                    "SearchOutput": "TEST, RUN, TEST, UBNILAWE EKITI",
                    "Reference": "13352613"
                },
                {
                    "ConsumerID": "14713314",
                    "SearchOutput": "TEST, RUN, , UBNILAWE EKITI",
                    "Reference": "14713314"
                }
            ]
        },
        {
            "Scoring": [
                {
                    "ConsumerID": "13352613",
                    "Surname": "TEST",
                    "FirstName": "RUN",
                    "OtherNames": "TEST",
                    "Gender": "Female",
                    "BirthDate": "12/12/1950",
                    "BankVerificationNo": "",
                    "RepaymentHistoryScore": "192/192",
                    "TotalAmountOwedScore": "165/165",
                    "TypesOfCreditScore": "40/55",
                    "LengthOfCreditHistoryScore": "83/83",
                    "NoOfAcctScore": "22/55",
                    "TotalConsumerScore": "802",
                    "Description": "LOW RISK",
                    "ScoreDate": "06/08/2023",
                    "TotalOutstandingDebt": "1.00",
                    "TotalForeignOutstandingDebt": "0.00",
                    "TotalAccountarrear": "0",
                    "TotalAmountOverdue": "5.00",
                    "TotalAccounts": "2",
                    "TotalForeignAccounts": "0",
                    "TotalaccountinGoodcondition": "2",
                    "TotalaccountinBadcondition": "0"
                }
            ]
        },
        {
            "EnquiryDetails": [
                {
                    "SubscriberEnquiryResultID": null,
                    "ProductID": null,
                    "MatchingRate": null,
                    "SubscriberEnquiryEngineID": null
                }
            ]
        }
    ]
 }
}

if(SubscriberEnquiryEngineID=='179065053' && EnquiryID=='60365779' && ConsumerID=='14713314')
{

    if(MergeList=='14713314' || MergeList=='')
    {
        recordsets = [
            {
                 //Hardcoded demo report
                "SubjectList": [
                    {
                        "ConsumerID": "14713314",
                        "SearchOutput": "TEST, RUN, , UBNILAWE EKITI",
                        "Reference": "14713314"
                    }
                ]
            },
            {
                "Scoring": [
                    {
                        "ConsumerID": "14713314",
                        "Surname": "TEST",
                        "FirstName": "RUN",
                        "OtherNames": "",
                        "Gender": "Female",
                        "BirthDate": "12/12/1950",
                        "BankVerificationNo": "",
                        "RepaymentHistoryScore": "192/192",
                        "TotalAmountOwedScore": "165/165",
                        "TypesOfCreditScore": "40/55",
                        "LengthOfCreditHistoryScore": "83/83",
                        "NoOfAcctScore": "11/55",
                        "TotalConsumerScore": "791",
                        "Description": "LOW RISK",
                        "ScoreDate": "06/08/2023",
                        "TotalOutstandingDebt": "0.00",
                        "TotalForeignOutstandingDebt": "0.00",
                        "TotalAccountarrear": "0",
                        "TotalAmountOverdue": "0.00",
                        "TotalAccounts": "1",
                        "TotalForeignAccounts": "0",
                        "TotalaccountinGoodcondition": "1",
                        "TotalaccountinBadcondition": "0"
                    }
                ]
            },
            {
                "EnquiryDetails": [
                    {
                        "SubscriberEnquiryResultID": null,
                        "ProductID": null,
                        "MatchingRate": null,
                        "SubscriberEnquiryEngineID": null
                    }
                ]
            }
        ]
    }

    if(MergeList=='13352613,14713314' || MergeList=='14713314,13352613')
    {
        recordsets = [
            {
                 //Hardcoded demo report
                "SubjectList": [
                    {
                        "ConsumerID": "13352613",
                        "SearchOutput": "TEST, RUN, TEST, UBNILAWE EKITI",
                        "Reference": "13352613"
                    },
                    {
                        "ConsumerID": "14713314",
                        "SearchOutput": "TEST, RUN, , UBNILAWE EKITI",
                        "Reference": "14713314"
                    }
                ]
            },
            {
                "Scoring": [
                    {
                        "ConsumerID": "13352613",
                        "Surname": "TEST",
                        "FirstName": "RUN",
                        "OtherNames": "TEST",
                        "Gender": "Female",
                        "BirthDate": "12/12/1950",
                        "BankVerificationNo": "",
                        "RepaymentHistoryScore": "192/192",
                        "TotalAmountOwedScore": "165/165",
                        "TypesOfCreditScore": "40/55",
                        "LengthOfCreditHistoryScore": "83/83",
                        "NoOfAcctScore": "22/55",
                        "TotalConsumerScore": "802",
                        "Description": "LOW RISK",
                        "ScoreDate": "06/08/2023",
                        "TotalOutstandingDebt": "1.00",
                        "TotalForeignOutstandingDebt": "0.00",
                        "TotalAccountarrear": "0",
                        "TotalAmountOverdue": "5.00",
                        "TotalAccounts": "2",
                        "TotalForeignAccounts": "0",
                        "TotalaccountinGoodcondition": "2",
                        "TotalaccountinBadcondition": "0"
                    }
                ]
            },
            {
                "EnquiryDetails": [
                    {
                        "SubscriberEnquiryResultID": null,
                        "ProductID": null,
                        "MatchingRate": null,
                        "SubscriberEnquiryEngineID": null
                    }
                ]
            }
        ]

    }

}
        return recordsets;

        } 
}

module.exports = new matchMssql();