const fs = require('fs');



class matchMssql {
    async commercialBasicReportBinary(req, res, decodedObj) {

       
            const BinaryReport = fs.readFileSync(__dirname+'/reports/CommercialBasicBinary.txt', 'utf8', (err, data) => {
                if(err) {
                    return res.statusCode = 500;
                }

                else {
                    res.setHeader('Content-Type', 'text/plain');
                    // BinaryReport = data;
                    // res.write(data);
                    return {data};
                }


            });
        //    console.log(BinaryReport);
            return BinaryReport;
            
       

    }
   
}

module.exports = new matchMssql();