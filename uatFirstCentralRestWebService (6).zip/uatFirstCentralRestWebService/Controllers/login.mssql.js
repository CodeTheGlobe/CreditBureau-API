// const mssql = require('mssql');
// const mssqlcon = require("../Config");
//let username = 'imafidonj';
//let password = 'imafidon';

let storedProc = 'WS_spFetchUser';

class loginMssql {
    async getTicket(req, res) {

        // const conn = await mssqlcon.getConnection();
       // const res = await conn.request().query('select top 3 * from consumer');
       // return res
       
    //    function convertObjectToLowerCase(obj) {
    //     if (typeof obj !== 'object' || obj === null) {
    //         return obj;
    //       }
      
    //     const converted = {};
    //     for (const key in obj) {
    //         const convertedKey = key.toLowerCase();
    //         const value = obj[key];
    //         const convertedValue = convertObjectToLowerCase(value);
    //         converted[convertedKey] = convertedValue;
    //       }
      
    //     return converted;
    //   }

        
            
            // const newObject = convertObjectToLowerCase(req.body);
                const username = req.username;
                const password = req.password;
                let recordset = {};
if(username=='Demo' && password=='demo@123' || username=='demo' && password=='demo@123')
{
               
                recordset = {username,password};

 }

 else 

res.json({"Error":'Wrong Inputs.The credentials are not on our database.Correct them and try again.'});
                return recordset;
        
    }
}


module.exports = new loginMssql();