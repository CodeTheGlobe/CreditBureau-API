const fs = require('fs');


class matchMssql {
    async commercialfullCreditBinary(req, res, decodedObj) {
       
            //read demo base64 string from file
            const BinaryReport = fs.readFileSync(__dirname+'/reports/CommercialFullBinary.txt', 'utf8', (err, data) => {
                if(err) {
                    return res.statusCode = 500;
                }

                else {
                    res.setHeader('Content-Type', 'text/plain');
                    
                    return {data};
                }


            });
        //    console.log(BinaryReport);
            return BinaryReport;

        }
}

module.exports = new matchMssql();