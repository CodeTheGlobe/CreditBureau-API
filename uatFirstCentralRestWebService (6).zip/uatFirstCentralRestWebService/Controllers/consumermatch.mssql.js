// const mssql = require('mssql');
// const mssqlcon = require("../Config");


// let storedProc = 'spConsumer_S_Match_Easy_Web';

class matchMssql {
    async consumermatch(req, res, decodedObj) {
        
        // const conn = await mssqlcon.getConnection();
   
            
            const Identification = req.identification;
            const ConsumerName = req.consumername.toLowerCase();
            const DateOfBirth = req.dateofbirth;
            let recordsets = [];

if(Identification=='22471069115' || (ConsumerName=='amos testi' && DateOfBirth=='26/01/1977'))
{
             recordsets = [
                {
                    "MatchedConsumer": [
                        {
                            "MatchingEngineID": "179064971",
                            "EnquiryID": "60365700",
                            "ConsumerID": "2599049",
                            "Reference": "C60365700-2599049",
                            "IDNo": null,
                            "PassportNo": null,
                            "PencomIDno": null,
                            "VoterID": null,
                            "DriversLicenseNo": null,
                            "FirstName": "Testi",
                            "Surname": null,
                            "SecondName": "Amos",
                            "OtherNames": "",
                            "Address": "College Road Abaro Aladje",
                            "BirthDate": "1977-01-26",
                            "GenderInd": null,
                            "AccountNo": null,
                            "TelePhoneNumber": "",
                            "MatchingRate": 90
                        }
                    ]
                }
            ];
 }

        else if(Identification=='22471069116' || (ConsumerName=='test run' && DateOfBirth=='12/12/1950'))
{
             recordsets = [
                {
                    "MatchedConsumer": [
                        {
                            "MatchingEngineID": "179065053",
                            "EnquiryID": "60365779",
                            "ConsumerID": "13352613",
                            "Reference": "C60365779-13352613",
                            "IDNo": null,
                            "PassportNo": null,
                            "PencomIDno": null,
                            "VoterID": null,
                            "DriversLicenseNo": null,
                            "FirstName": "RUN",
                            "Surname": null,
                            "SecondName": "TEST",
                            "OtherNames": "TEST",
                            "Address": "UBNILAWE EKITI",
                            "BirthDate": "1950-12-12",
                            "GenderInd": null,
                            "AccountNo": null,
                            "TelePhoneNumber": "",
                            "MatchingRate": 95
                        },
                        {
                            "MatchingEngineID": "179065053",
                            "EnquiryID": "60365779",
                            "ConsumerID": "14713314",
                            "Reference": "C60365779-14713314",
                            "IDNo": null,
                            "PassportNo": null,
                            "PencomIDno": null,
                            "VoterID": null,
                            "DriversLicenseNo": null,
                            "FirstName": "RUN",
                            "Surname": null,
                            "SecondName": "TEST",
                            "OtherNames": "",
                            "Address": "UBNILAWE EKITI",
                            "BirthDate": "1950-12-12",
                            "GenderInd": null,
                            "AccountNo": null,
                            "TelePhoneNumber": "",
                            "MatchingRate": 95
                        }
                    ]
                }
            ];
        }

         else {
            recordsets = [
                
                {
                    "MatchedConsumer": [
                {
                    "MatchingEngineID": "179064971",
                    "EnquiryID": "60365700",
                    "ConsumerID": "0",
                    "Reference": "C60412700-1599060",
                    "IDNo": null,
                    "PassportNo": null,
                    "PencomIDno": null,
                    "VoterID": null,
                    "DriversLicenseNo": null,
                    "FirstName": null,
                    "Surname": null,
                    "SecondName": null,
                    "OtherNames": null,
                    "Address": null,
                    "BirthDate": null,
                    "GenderInd": null,
                    "AccountNo": null,
                    "TelePhoneNumber": "",
                    "MatchingRate": 0
                }
            ]
        }
    ]

        }
    
            return recordsets;
        }
}

module.exports = new matchMssql();