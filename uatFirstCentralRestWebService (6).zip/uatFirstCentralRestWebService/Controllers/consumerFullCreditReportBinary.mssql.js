const fs = require('fs');
//const binarypath = 'reports/BinaryDetailed2599049.txt';
// let BinaryReport = '';



class matchMssql {
    async consumerfullCreditBinary(req, res, decodedObj) {
        // const RealProductID = 45;
        // const EnquiryInput = [];
        // const Report = 'Consumer Full Credit Report Binary';
        // const conn = await mssqlcon.getConnection();

      
            //read demo base64 string from file
            const BinaryReport = fs.readFileSync(__dirname+'/reports/BinaryDetailed2599049.txt', 'utf8', (err, data) => {
                if(err) {
                    return res.statusCode = 500;
                }

                else {
                    res.setHeader('Content-Type', 'text/plain');
                   
                    return {data};
                }


            });
        //    console.log(BinaryReport);
            return BinaryReport;

        } 
}

module.exports = new matchMssql();