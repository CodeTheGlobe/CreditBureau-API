


class matchMssql {
    async consumerfullCredit(req, res, decodedObj) {
        // const RealProductID = 45;
        // const EnquiryInput = [];
        // const Report = 'Consumer Full Creit Report';
        // const conn = await mssqlcon.getConnection();

      

            const SubscriberEnquiryEngineID = req.subscriberenquiryengineid;
            const EnquiryID = req.enquiryid;
            const ConsumerID = req.consumerid;
            const MergeList = req.consumermergelist;
            let recordsets = [];
            
            
if(SubscriberEnquiryEngineID=='179064971' && EnquiryID=='60365700' && ConsumerID=='2599049')
{
             recordsets = [
                {
                     //Hardcoded demo report
                    "SubjectList": [
                        {
                            "ConsumerID": "2599049",
                            "SearchOutput": "Amos, Testi, , College Road Abaro Aladje",
                            "Reference": "2599049"
                        }
                    ]
                },
                {
                    "PersonalDetailsSummary": [
                        {
                            "ConsumerID": "2599049",
                            "Header": "PERSONAL DETAILS SUMMARY: Amos Testi ",
                            "ReferenceNo": null,
                            "Nationality": "Nigeria",
                            "NationalIDNo": "",
                            "PassportNo": null,
                            "DriversLicenseNo": null,
                            "BankVerificationNo": "22471069115",
                            "PencomIDNo": "",
                            "OtheridNo": "",
                            "BirthDate": "26/01/1977",
                            "Dependants": "0",
                            "Gender": "Female",
                            "MaritalStatus": null,
                            "ResidentialAddress1": "College Road Abaro Aladje",
                            "ResidentialAddress2": "Delta",
                            "ResidentialAddress3": "",
                            "ResidentialAddress4": " ",
                            "PostalAddress1": null,
                            "PostalAddress2": null,
                            "PostalAddress3": null,
                            "PostalAddress4": null,
                            "HomeTelephoneNo": null,
                            "WorkTelephoneNo": null,
                            "CellularNo": "",
                            "EmailAddress": "",
                            "EmployerDetail": null,
                            "PropertyOwnedType": "",
                            "Surname": "Amos",
                            "FirstName": "Testi",
                            "OtherNames": ""
                        }
                    ]
                },
                {
                    "DeliquencyInformation": [
                        {
                            "SubscriberName": "",
                            "AccountNo": "",
                            "PeriodNum": "",
                            "MonthsinArrears": ""
                        }
                    ]
                },
                {
                    "CreditAccountSummary": [
                        {
                            "TotalMonthlyInstalment": "17,205.00",
                            "TotalOutstandingdebt": "0.00",
                            "TotalAccountarrear": "2",
                            "Amountarrear": "0.00",
                            "TotalAccounts": "7",
                            "TotalAccounts1": "0",
                            "TotalaccountinGodcondition": "6",
                            "TotalaccountinGoodcondition": "6",
                            "TotalNumberofJudgement": "0",
                            "TotalJudgementAmount": "0",
                            "LastJudgementDate": "-",
                            "TotalNumberofDishonoured": "0",
                            "TotalDishonouredAmount": "0.00",
                            "LastBouncedChequesDate": null,
                            "TotalMonthlyInstalment1": "0.00",
                            "TotalOutstandingdebt1": "0.00",
                            "TotalAccountarrear1": "0",
                            "Amountarrear1": "0.00",
                            "TotalaccountinGodcondition1": "0",
                            "TotalaccountinBadcondition": "0",
                            "TotalNumberofJudgement1": "0",
                            "TotalJudgementAmount1": "0",
                            "LastJudgementDate1": "-",
                            "TotalNumberofDishonoured1": "0",
                            "TotalDishonouredAmount1": "0.00",
                            "LastBouncedChequesDate1": null,
                            "Rating": "118"
                        }
                    ]
                },
                {
                    "CreditAccountRating": [
                        {
                            "NoOfHomeLoanAccountsGood": "0",
                            "NoOfHomeLoanAccountsBad": "0",
                            "NoOfAutoLoanccountsGood": "0",
                            "NoOfAutoLoanAccountsBad": "0",
                            "NoOfStudyLoanAccountsGood": "0",
                            "NoOfStudyLoanAccountsBad": "0",
                            "NoOfPersonalLoanAccountsGood": "0",
                            "NoOfPersonalLoanAccountsBad": "0",
                            "NoOfCreditCardAccountsGood": "0",
                            "NoOfCreditCardAccountsBad": "0",
                            "NoOfRetailAccountsGood": "0",
                            "NoOfRetailAccountsBad": "0",
                            "NoOfJointLoanAccountsGood": "0",
                            "NoOfJointLoanAccountsBad": "0",
                            "NoOfTelecomAccountsGood": "0",
                            "NoOfTelecomAccountsBad": "0",
                            "NoOfOtherAccountsGood": "6",
                            "NoOfOtherAccountsBad": "0"
                        }
                    ]
                },
                {
                    "CreditAgreementSummary": [
                        {
                            "DateAccountOpened": "19/08/2021",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "032SPLG212310004",
                            "SubAccountNo": "",
                            "IndicatorDescription": null,
                            "OpeningBalanceAmt": "150,000.00",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "CurrentBalanceAmt": null,
                            "InstalmentAmount": null,
                            "AmountOverdue": "0.00",
                            "ClosedDate": "21/03/2022",
                            "LoanDuration": "214",
                            "RepaymentFrequency": "We",
                            "LastUpdatedDate": "21/04/2023",
                            "PerformanceStatus": "Performing",
                            "AccountStatus": "Closed"
                        },
                        {
                            "DateAccountOpened": "18/11/2020",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "032SPLI000000088",
                            "SubAccountNo": "",
                            "IndicatorDescription": null,
                            "OpeningBalanceAmt": "85,298.25",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "CurrentBalanceAmt": null,
                            "InstalmentAmount": null,
                            "AmountOverdue": "0.00",
                            "ClosedDate": "18/05/2021",
                            "LoanDuration": "151",
                            "RepaymentFrequency": "We",
                            "LastUpdatedDate": "21/04/2023",
                            "PerformanceStatus": "Watchlist",
                            "AccountStatus": "Closed"
                        },
                        {
                            "DateAccountOpened": "31/08/2017",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "5014734231",
                            "SubAccountNo": "",
                            "IndicatorDescription": null,
                            "OpeningBalanceAmt": "60,000.00",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "CurrentBalanceAmt": "0.00",
                            "InstalmentAmount": "2,406.06",
                            "AmountOverdue": "0.00",
                            "ClosedDate": "04/04/2018",
                            "LoanDuration": "7",
                            "RepaymentFrequency": "Weekly",
                            "LastUpdatedDate": "30/08/2018",
                            "PerformanceStatus": "Performing",
                            "AccountStatus": "Closed"
                        },
                        {
                            "DateAccountOpened": "17/04/2018",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "5015245293",
                            "SubAccountNo": "",
                            "IndicatorDescription": null,
                            "OpeningBalanceAmt": "90,000.00",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "CurrentBalanceAmt": "0.00",
                            "InstalmentAmount": "3,615.23",
                            "AmountOverdue": "0.00",
                            "ClosedDate": "21/11/2018",
                            "LoanDuration": "7",
                            "RepaymentFrequency": "Weekly",
                            "LastUpdatedDate": "11/01/2019",
                            "PerformanceStatus": "Performing",
                            "AccountStatus": "Closed"
                        },
                        {
                            "DateAccountOpened": "07/12/2018",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "5015825706",
                            "SubAccountNo": "",
                            "IndicatorDescription": null,
                            "OpeningBalanceAmt": "100,000.00",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "CurrentBalanceAmt": "0.00",
                            "InstalmentAmount": "4,016.92",
                            "AmountOverdue": "0.00",
                            "ClosedDate": "17/07/2019",
                            "LoanDuration": "7",
                            "RepaymentFrequency": "Not Available",
                            "LastUpdatedDate": "01/05/2019",
                            "PerformanceStatus": "Performing",
                            "AccountStatus": "Closed"
                        },
                        {
                            "DateAccountOpened": "20/05/2020",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "5016864710",
                            "SubAccountNo": "",
                            "IndicatorDescription": null,
                            "OpeningBalanceAmt": "150,000.00",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "CurrentBalanceAmt": "0.00",
                            "InstalmentAmount": "6,000.02",
                            "AmountOverdue": "0.00",
                            "ClosedDate": "16/12/2020",
                            "LoanDuration": "7",
                            "RepaymentFrequency": "Weekly",
                            "LastUpdatedDate": "17/12/2020",
                            "PerformanceStatus": "Performing",
                            "AccountStatus": "Closed"
                        },
                        {
                            "DateAccountOpened": "03/09/2020",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "5470023209",
                            "SubAccountNo": "",
                            "IndicatorDescription": null,
                            "OpeningBalanceAmt": "12,850.00",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "CurrentBalanceAmt": "0.00",
                            "InstalmentAmount": "1,167.12",
                            "AmountOverdue": "0.00",
                            "ClosedDate": "02/09/2021",
                            "LoanDuration": "365",
                            "RepaymentFrequency": "Not Available",
                            "LastUpdatedDate": "30/11/2020",
                            "PerformanceStatus": "Performing",
                            "AccountStatus": "Closed"
                        }
                    ]
                },
                {
                    "AccountMonthlyPaymentHistoryHeader": [
                        {
                            "TableName": "Consumer24MonthlyPaymentHeader",
                            "DisplayText": "Consumer 24 Monthly Payment Header",
                            "Company": "Company",
                            "MH24": "2021\nJUN",
                            "MH23": "2021\nJUL",
                            "MH22": "2021\nAUG",
                            "MH21": "2021\nSEP",
                            "MH20": "2021\nOCT",
                            "MH19": "2021\nNOV",
                            "MH18": "2021\nDEC",
                            "MH17": "2022\nJAN",
                            "MH16": "2022\nFEB",
                            "MH15": "2022\nMAR",
                            "MH14": "2022\nAPR",
                            "MH13": "2022\nMAY",
                            "MH12": "2022\nJUN",
                            "MH11": "2022\nJUL",
                            "MH10": "2022\nAUG",
                            "MH09": "2022\nSEP",
                            "MH08": "2022\nOCT",
                            "MH07": "2022\nNOV",
                            "MH06": "2022\nDEC",
                            "MH05": "2023\nJAN",
                            "MH04": "2023\nFEB",
                            "MH03": "2023\nMAR",
                            "MH02": "2023\nAPR",
                            "MH01": "2023\nMAY"
                        }
                    ]
                },
                {
                    "AccountMonthlyPaymentHistory": [
                        {
                            "Header": "Details of Credit Agreement with \"LAPO Microfinance Bank Limited Edo\" for Account Number: 032SPLG212310004",
                            "TableName": "Consumer24MonthlyPayment",
                            "DisplayText": "Consumer 24 Monthly Payment",
                            "DateAccountOpened": "19/08/2021",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "032SPLG212310004",
                            "SubAccountNo": "",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "IndicatorDescription": null,
                            "MonthlyInstalmentAmt": null,
                            "LastPaymentDate": null,
                            "SubscriberTypeInd": "M",
                            "AccountNote": "",
                            "RepaymentFrequencyCode": "We",
                            "OpeningBalanceAmt": "150,000.00",
                            "CurrentBalanceAmt": null,
                            "AmountOverdue": "0.00",
                            "ClosedDate": "21/03/2022",
                            "LastUpdatedDate": "21/04/2023",
                            "PerformanceStatus": "Performing",
                            "LoanDuration": "214 Day(s)",
                            "AccountStatus": "Closed",
                            "M01": "#",
                            "M02": "#",
                            "M03": "0",
                            "M04": "#",
                            "M05": "0",
                            "M06": "0",
                            "M07": "0",
                            "M08": "0",
                            "M09": "#",
                            "M10": "0",
                            "M11": "0",
                            "M12": "0",
                            "M13": "0",
                            "M14": "#",
                            "M15": "101",
                            "M16": "0",
                            "M17": "#",
                            "M18": "#",
                            "M19": "#",
                            "M20": "0",
                            "M21": "0",
                            "M22": "#",
                            "M23": "#",
                            "M24": "#"
                        },
                        {
                            "Header": "Details of Credit Agreement with \"LAPO Microfinance Bank Limited Edo\" for Account Number: 032SPLI000000088",
                            "TableName": "Consumer24MonthlyPayment",
                            "DisplayText": "Consumer 24 Monthly Payment",
                            "DateAccountOpened": "18/11/2020",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "032SPLI000000088",
                            "SubAccountNo": "",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "IndicatorDescription": null,
                            "MonthlyInstalmentAmt": null,
                            "LastPaymentDate": null,
                            "SubscriberTypeInd": "M",
                            "AccountNote": "",
                            "RepaymentFrequencyCode": "We",
                            "OpeningBalanceAmt": "85,298.25",
                            "CurrentBalanceAmt": null,
                            "AmountOverdue": "0.00",
                            "ClosedDate": "18/05/2021",
                            "LastUpdatedDate": "21/04/2023",
                            "PerformanceStatus": "Watchlist",
                            "LoanDuration": "151 Day(s)",
                            "AccountStatus": "Closed",
                            "M01": "#",
                            "M02": "#",
                            "M03": "0",
                            "M04": "#",
                            "M05": "0",
                            "M06": "#",
                            "M07": "0",
                            "M08": "0",
                            "M09": "#",
                            "M10": "0",
                            "M11": "0",
                            "M12": "0",
                            "M13": "0",
                            "M14": "0",
                            "M15": "0",
                            "M16": "0",
                            "M17": "#",
                            "M18": "#",
                            "M19": "#",
                            "M20": "0",
                            "M21": "0",
                            "M22": "#",
                            "M23": "0",
                            "M24": "#"
                        },
                        {
                            "Header": "Details of Credit Agreement with \"LAPO Microfinance Bank Limited Edo\" for Account Number: 5014734231",
                            "TableName": "Consumer24MonthlyPayment",
                            "DisplayText": "Consumer 24 Monthly Payment",
                            "DateAccountOpened": "31/08/2017",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "5014734231",
                            "SubAccountNo": "",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "IndicatorDescription": null,
                            "MonthlyInstalmentAmt": "0.00",
                            "LastPaymentDate": null,
                            "SubscriberTypeInd": "M",
                            "AccountNote": "",
                            "RepaymentFrequencyCode": "Weekly",
                            "OpeningBalanceAmt": "60,000.00",
                            "CurrentBalanceAmt": "2,406.06",
                            "AmountOverdue": "0.00",
                            "ClosedDate": "04/04/2018",
                            "LastUpdatedDate": "30/08/2018",
                            "PerformanceStatus": "Performing",
                            "LoanDuration": "7 Day(s)",
                            "AccountStatus": "Closed",
                            "M01": "#",
                            "M02": "#",
                            "M03": "#",
                            "M04": "#",
                            "M05": "#",
                            "M06": "#",
                            "M07": "#",
                            "M08": "#",
                            "M09": "#",
                            "M10": "#",
                            "M11": "#",
                            "M12": "#",
                            "M13": "#",
                            "M14": "#",
                            "M15": "#",
                            "M16": "#",
                            "M17": "#",
                            "M18": "#",
                            "M19": "#",
                            "M20": "#",
                            "M21": "#",
                            "M22": "#",
                            "M23": "#",
                            "M24": "#"
                        },
                        {
                            "Header": "Details of Credit Agreement with \"LAPO Microfinance Bank Limited Edo\" for Account Number: 5015245293",
                            "TableName": "Consumer24MonthlyPayment",
                            "DisplayText": "Consumer 24 Monthly Payment",
                            "DateAccountOpened": "17/04/2018",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "5015245293",
                            "SubAccountNo": "",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "IndicatorDescription": null,
                            "MonthlyInstalmentAmt": "0.00",
                            "LastPaymentDate": null,
                            "SubscriberTypeInd": "M",
                            "AccountNote": "",
                            "RepaymentFrequencyCode": "Weekly",
                            "OpeningBalanceAmt": "90,000.00",
                            "CurrentBalanceAmt": "3,615.23",
                            "AmountOverdue": "0.00",
                            "ClosedDate": "21/11/2018",
                            "LastUpdatedDate": "11/01/2019",
                            "PerformanceStatus": "Performing",
                            "LoanDuration": "7 Day(s)",
                            "AccountStatus": "Closed",
                            "M01": "#",
                            "M02": "#",
                            "M03": "#",
                            "M04": "#",
                            "M05": "#",
                            "M06": "#",
                            "M07": "#",
                            "M08": "#",
                            "M09": "#",
                            "M10": "#",
                            "M11": "#",
                            "M12": "#",
                            "M13": "#",
                            "M14": "#",
                            "M15": "#",
                            "M16": "#",
                            "M17": "#",
                            "M18": "#",
                            "M19": "#",
                            "M20": "#",
                            "M21": "#",
                            "M22": "#",
                            "M23": "#",
                            "M24": "#"
                        },
                        {
                            "Header": "Details of Credit Agreement with \"LAPO Microfinance Bank Limited Edo\" for Account Number: 5015825706",
                            "TableName": "Consumer24MonthlyPayment",
                            "DisplayText": "Consumer 24 Monthly Payment",
                            "DateAccountOpened": "07/12/2018",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "5015825706",
                            "SubAccountNo": "",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "IndicatorDescription": null,
                            "MonthlyInstalmentAmt": "0.00",
                            "LastPaymentDate": "27/03/2019",
                            "SubscriberTypeInd": "M",
                            "AccountNote": "",
                            "RepaymentFrequencyCode": "Not Available",
                            "OpeningBalanceAmt": "100,000.00",
                            "CurrentBalanceAmt": "4,016.92",
                            "AmountOverdue": "0.00",
                            "ClosedDate": "17/07/2019",
                            "LastUpdatedDate": "01/05/2019",
                            "PerformanceStatus": "Performing",
                            "LoanDuration": "7 Day(s)",
                            "AccountStatus": "Closed",
                            "M01": "#",
                            "M02": "#",
                            "M03": "#",
                            "M04": "#",
                            "M05": "#",
                            "M06": "#",
                            "M07": "#",
                            "M08": "#",
                            "M09": "#",
                            "M10": "#",
                            "M11": "#",
                            "M12": "#",
                            "M13": "#",
                            "M14": "#",
                            "M15": "#",
                            "M16": "#",
                            "M17": "#",
                            "M18": "#",
                            "M19": "#",
                            "M20": "#",
                            "M21": "#",
                            "M22": "#",
                            "M23": "#",
                            "M24": "#"
                        },
                        {
                            "Header": "Details of Credit Agreement with \"LAPO Microfinance Bank Limited Edo\" for Account Number: 5016864710",
                            "TableName": "Consumer24MonthlyPayment",
                            "DisplayText": "Consumer 24 Monthly Payment",
                            "DateAccountOpened": "20/05/2020",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "5016864710",
                            "SubAccountNo": "",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "IndicatorDescription": null,
                            "MonthlyInstalmentAmt": "0.00",
                            "LastPaymentDate": "25/11/2020",
                            "SubscriberTypeInd": "M",
                            "AccountNote": "",
                            "RepaymentFrequencyCode": "Weekly",
                            "OpeningBalanceAmt": "150,000.00",
                            "CurrentBalanceAmt": "6,000.02",
                            "AmountOverdue": "0.00",
                            "ClosedDate": "16/12/2020",
                            "LastUpdatedDate": "17/12/2020",
                            "PerformanceStatus": "Performing",
                            "LoanDuration": "7 Day(s)",
                            "AccountStatus": "Closed",
                            "M01": "#",
                            "M02": "#",
                            "M03": "#",
                            "M04": "#",
                            "M05": "#",
                            "M06": "#",
                            "M07": "#",
                            "M08": "#",
                            "M09": "#",
                            "M10": "#",
                            "M11": "#",
                            "M12": "#",
                            "M13": "#",
                            "M14": "#",
                            "M15": "#",
                            "M16": "#",
                            "M17": "#",
                            "M18": "#",
                            "M19": "#",
                            "M20": "#",
                            "M21": "#",
                            "M22": "#",
                            "M23": "#",
                            "M24": "#"
                        },
                        {
                            "Header": "Details of Credit Agreement with \"LAPO Microfinance Bank Limited Edo\" for Account Number: 5470023209",
                            "TableName": "Consumer24MonthlyPayment",
                            "DisplayText": "Consumer 24 Monthly Payment",
                            "DateAccountOpened": "03/09/2020",
                            "SubscriberName": "LAPO Microfinance Bank Limited Edo",
                            "AccountNo": "5470023209",
                            "SubAccountNo": "",
                            "Currency": "NGN",
                            "CurrentBalanceDebitInd": null,
                            "IndicatorDescription": null,
                            "MonthlyInstalmentAmt": "0.00",
                            "LastPaymentDate": "02/09/2021",
                            "SubscriberTypeInd": "M",
                            "AccountNote": "",
                            "RepaymentFrequencyCode": "Not Available",
                            "OpeningBalanceAmt": "12,850.00",
                            "CurrentBalanceAmt": "1,167.12",
                            "AmountOverdue": "0.00",
                            "ClosedDate": "02/09/2021",
                            "LastUpdatedDate": "30/11/2020",
                            "PerformanceStatus": "Performing",
                            "LoanDuration": "365 Day(s)",
                            "AccountStatus": "Closed",
                            "M01": "#",
                            "M02": "#",
                            "M03": "#",
                            "M04": "#",
                            "M05": "#",
                            "M06": "#",
                            "M07": "#",
                            "M08": "#",
                            "M09": "#",
                            "M10": "#",
                            "M11": "#",
                            "M12": "#",
                            "M13": "#",
                            "M14": "#",
                            "M15": "#",
                            "M16": "#",
                            "M17": "#",
                            "M18": "#",
                            "M19": "#",
                            "M20": "#",
                            "M21": "#",
                            "M22": "#",
                            "M23": "#",
                            "M24": "#"
                        }
                    ]
                },
                {
                    "GuarantorCount": [
                        {
                            "GuarantorsSecured": "0",
                            "Accounts": "0"
                        }
                    ]
                },
                {
                    "GuarantorDetails": [
                        {
                            "GuarantorFirstName": "",
                            "GuarantorOtherName": "",
                            "GuarantorNationalIDNo": "",
                            "GuarantorPassport": "",
                            "GuarantorDriverLicenceNo": "",
                            "GuarantorPENCOMIDNo": "",
                            "GuarantorOtherID": "",
                            "GuarantorGender": "",
                            "GuarantorDateOfBirth": "",
                            "GuarantorAddress1": "",
                            "GuarantorAddress2": "",
                            "GuarantorAddress3": "",
                            "GuarantorHomeTelephone": "",
                            "GuarantorworkTelephone": "",
                            "GuarantorMobileTelephone": ""
                        }
                    ]
                },
                {
                    "EnquiryHistoryTop": [
                        {
                            "SubscriberEnquiryResultID": null,
                            "DateRequested": null,
                            "SubscriberName": null,
                            "EnquiryReason": null,
                            "CompanyTelephoneNo": null
                        }
                    ]
                },
                {
                    "IdentificationHistory": [
                        {
                            "UpDateDate": null,
                            "UpDateOnDate": null,
                            "IdentificationNumber": null,
                            "IdentificationType": null
                        }
                    ]
                },
                {
                    "AddressHistory": [
                        {
                            "UpDateDate": null,
                            "UpDateOnDate": null,
                            "Address1": null,
                            "Address2": null,
                            "Address3": null,
                            "Address4": null,
                            "AddressTypeInd": null
                        }
                    ]
                },
                {
                    "EmploymentHistory": [
                        {
                            "UpDateDate": null,
                            "UpDateOnDate": null,
                            "EmployerDetail": null,
                            "Occupation": null
                        }
                    ]
                },
                {
                    "TelephoneHistory": []
                },
                {
                    "EnquiryDetails": [
                        {
                            "SubscriberEnquiryResultID": null,
                            "ProductID": null,
                            "MatchingRate": null,
                            "SubscriberEnquiryEngineID": null
                        }
                    ]
                }
            ]
 }



     
if(SubscriberEnquiryEngineID=='179065053' && EnquiryID=='60365779' && ConsumerID=='13352613')
{

if(MergeList=='13352613' || MergeList=='')
{
    recordsets = [
        {
             //Hardcoded demo report
            "SubjectList": [
                {
                    "ConsumerID": "13352613",
                    "SearchOutput": "TEST, RUN, TEST, UBNILAWE EKITI",
                    "Reference": "13352613"
                }
            ]
        },
        {
            "PersonalDetailsSummary": [
                {
                    "ConsumerID": "13352613",
                    "Header": "PERSONAL DETAILS SUMMARY: TEST RUN TEST",
                    "ReferenceNo": null,
                    "Nationality": "Nigeria",
                    "NationalIDNo": "",
                    "PassportNo": null,
                    "DriversLicenseNo": null,
                    "BankVerificationNo": "",
                    "PencomIDNo": "",
                    "OtheridNo": "",
                    "BirthDate": "12/12/1950",
                    "Dependants": "0",
                    "Gender": "Female",
                    "MaritalStatus": null,
                    "ResidentialAddress1": "UBNILAWE EKITI",
                    "ResidentialAddress2": "",
                    "ResidentialAddress3": "",
                    "ResidentialAddress4": "13 ",
                    "PostalAddress1": "UBNILAWE EKITI",
                    "PostalAddress2": "",
                    "PostalAddress3": "",
                    "PostalAddress4": "13 ",
                    "HomeTelephoneNo": null,
                    "WorkTelephoneNo": null,
                    "CellularNo": "",
                    "EmailAddress": "",
                    "EmployerDetail": null,
                    "PropertyOwnedType": "",
                    "Surname": "TEST",
                    "FirstName": "RUN",
                    "OtherNames": "TEST"
                }
            ]
        },
        {
            "DeliquencyInformation": [
                {
                    "SubscriberName": "",
                    "AccountNo": "",
                    "PeriodNum": "",
                    "MonthsinArrears": ""
                }
            ]
        },
        {
            "CreditAccountSummary": [
                {
                    "TotalMonthlyInstalment": "0.00",
                    "TotalOutstandingdebt": "1.00",
                    "TotalAccountarrear": "0",
                    "Amountarrear": "1.00",
                    "TotalAccounts": "1",
                    "TotalAccounts1": "0",
                    "TotalaccountinGodcondition": "0",
                    "TotalaccountinGoodcondition": "0",
                    "TotalNumberofJudgement": "0",
                    "TotalJudgementAmount": "0",
                    "LastJudgementDate": "-",
                    "TotalNumberofDishonoured": "0",
                    "TotalDishonouredAmount": "0.00",
                    "LastBouncedChequesDate": null,
                    "TotalMonthlyInstalment1": "0.00",
                    "TotalOutstandingdebt1": "0.00",
                    "TotalAccountarrear1": "0",
                    "Amountarrear1": "0.00",
                    "TotalaccountinGodcondition1": "0",
                    "TotalaccountinBadcondition": "0",
                    "TotalNumberofJudgement1": "0",
                    "TotalJudgementAmount1": "0",
                    "LastJudgementDate1": "-",
                    "TotalNumberofDishonoured1": "0",
                    "TotalDishonouredAmount1": "0.00",
                    "LastBouncedChequesDate1": null,
                    "Rating": "0"
                }
            ]
        },
        {
            "CreditAccountRating": [
                {
                    "NoOfHomeLoanAccountsGood": "0",
                    "NoOfHomeLoanAccountsBad": "0",
                    "NoOfAutoLoanccountsGood": "0",
                    "NoOfAutoLoanAccountsBad": "0",
                    "NoOfStudyLoanAccountsGood": "0",
                    "NoOfStudyLoanAccountsBad": "0",
                    "NoOfPersonalLoanAccountsGood": "0",
                    "NoOfPersonalLoanAccountsBad": "0",
                    "NoOfCreditCardAccountsGood": "0",
                    "NoOfCreditCardAccountsBad": "0",
                    "NoOfRetailAccountsGood": "0",
                    "NoOfRetailAccountsBad": "0",
                    "NoOfJointLoanAccountsGood": "0",
                    "NoOfJointLoanAccountsBad": "0",
                    "NoOfTelecomAccountsGood": "0",
                    "NoOfTelecomAccountsBad": "0",
                    "NoOfOtherAccountsGood": "0",
                    "NoOfOtherAccountsBad": "1"
                }
            ]
        },
        {
            "CreditAgreementSummary": [
                {
                    "DateAccountOpened": "19/06/2009",
                    "SubscriberName": "Union Bank Nigeria Plc Lagos",
                    "AccountNo": "000011111001",
                    "SubAccountNo": "",
                    "IndicatorDescription": null,
                    "OpeningBalanceAmt": "1.00",
                    "Currency": "NGN",
                    "CurrentBalanceDebitInd": "D",
                    "CurrentBalanceAmt": "1.00",
                    "InstalmentAmount": "0.00",
                    "AmountOverdue": "1.00",
                    "ClosedDate": null,
                    "LoanDuration": null,
                    "RepaymentFrequency": "Not Available",
                    "LastUpdatedDate": "22/10/2022",
                    "PerformanceStatus": "Doubtful",
                    "AccountStatus": "Closed"
                }
            ]
        },
        {
            "AccountMonthlyPaymentHistoryHeader": [
                {
                    "TableName": "Consumer24MonthlyPaymentHeader",
                    "DisplayText": "Consumer 24 Monthly Payment Header",
                    "Company": "Company",
                    "MH24": "2021\nJUN",
                    "MH23": "2021\nJUL",
                    "MH22": "2021\nAUG",
                    "MH21": "2021\nSEP",
                    "MH20": "2021\nOCT",
                    "MH19": "2021\nNOV",
                    "MH18": "2021\nDEC",
                    "MH17": "2022\nJAN",
                    "MH16": "2022\nFEB",
                    "MH15": "2022\nMAR",
                    "MH14": "2022\nAPR",
                    "MH13": "2022\nMAY",
                    "MH12": "2022\nJUN",
                    "MH11": "2022\nJUL",
                    "MH10": "2022\nAUG",
                    "MH09": "2022\nSEP",
                    "MH08": "2022\nOCT",
                    "MH07": "2022\nNOV",
                    "MH06": "2022\nDEC",
                    "MH05": "2023\nJAN",
                    "MH04": "2023\nFEB",
                    "MH03": "2023\nMAR",
                    "MH02": "2023\nAPR",
                    "MH01": "2023\nMAY"
                }
            ]
        },
        {
            "AccountMonthlyPaymentHistory": [
                {
                    "Header": "Details of Credit Agreement with \"Union Bank Nigeria Plc Lagos\" for Account Number: 000011111001",
                    "TableName": "Consumer24MonthlyPayment",
                    "DisplayText": "Consumer 24 Monthly Payment",
                    "DateAccountOpened": "19/06/2009",
                    "SubscriberName": "Union Bank Nigeria Plc Lagos",
                    "AccountNo": "000011111001",
                    "SubAccountNo": "",
                    "Currency": "NGN",
                    "CurrentBalanceDebitInd": "D",
                    "IndicatorDescription": null,
                    "MonthlyInstalmentAmt": "1.00",
                    "LastPaymentDate": "01/01/1900",
                    "SubscriberTypeInd": "C",
                    "AccountNote": "",
                    "RepaymentFrequencyCode": "Not Available",
                    "OpeningBalanceAmt": "1.00",
                    "CurrentBalanceAmt": "0.00",
                    "AmountOverdue": "1.00",
                    "ClosedDate": null,
                    "LastUpdatedDate": "22/10/2022",
                    "PerformanceStatus": "Doubtful",
                    "LoanDuration": "Not Available",
                    "AccountStatus": "Closed",
                    "M01": "#",
                    "M02": "#",
                    "M03": "#",
                    "M04": "#",
                    "M05": "#",
                    "M06": "#",
                    "M07": "#",
                    "M08": "#",
                    "M09": "#",
                    "M10": "#",
                    "M11": "#",
                    "M12": "#",
                    "M13": "#",
                    "M14": "#",
                    "M15": "#",
                    "M16": "#",
                    "M17": "#",
                    "M18": "#",
                    "M19": "#",
                    "M20": "#",
                    "M21": "#",
                    "M22": "#",
                    "M23": "#",
                    "M24": "#"
                }
            ]
        },
        {
            "GuarantorCount": [
                {
                    "GuarantorsSecured": "0",
                    "Accounts": "0"
                }
            ]
        },
        {
            "GuarantorDetails": [
                {
                    "GuarantorFirstName": "",
                    "GuarantorOtherName": "",
                    "GuarantorNationalIDNo": "",
                    "GuarantorPassport": "",
                    "GuarantorDriverLicenceNo": "",
                    "GuarantorPENCOMIDNo": "",
                    "GuarantorOtherID": "",
                    "GuarantorGender": "",
                    "GuarantorDateOfBirth": "",
                    "GuarantorAddress1": "",
                    "GuarantorAddress2": "",
                    "GuarantorAddress3": "",
                    "GuarantorHomeTelephone": "",
                    "GuarantorworkTelephone": "",
                    "GuarantorMobileTelephone": ""
                }
            ]
        },
        {
            "EnquiryHistoryTop": [
                {
                    "SubscriberEnquiryResultID": null,
                    "DateRequested": null,
                    "SubscriberName": null,
                    "EnquiryReason": null,
                    "CompanyTelephoneNo": null
                }
            ]
        },
        {
            "IdentificationHistory": [
                {
                    "UpDateDate": null,
                    "UpDateOnDate": null,
                    "IdentificationNumber": null,
                    "IdentificationType": null
                }
            ]
        },
        {
            "AddressHistory": [
                {
                    "UpDateDate": null,
                    "UpDateOnDate": null,
                    "Address1": null,
                    "Address2": null,
                    "Address3": null,
                    "Address4": null,
                    "AddressTypeInd": null
                }
            ]
        },
        {
            "EmploymentHistory": [
                {
                    "UpDateDate": null,
                    "UpDateOnDate": null,
                    "EmployerDetail": null,
                    "Occupation": null
                }
            ]
        },
        {
            "TelephoneHistory": []
        },
        {
            "EnquiryDetails": [
                {
                    "SubscriberEnquiryResultID": null,
                    "ProductID": null,
                    "MatchingRate": null,
                    "SubscriberEnquiryEngineID": null
                }
            ]
        }
    ]
 }

 if(MergeList=='13352613,14713314' || MergeList=='14713314,13352613')
{
    recordsets = [
        {
             //Hardcoded demo report
            "SubjectList": [
                {
                    "ConsumerID": "13352613",
                    "SearchOutput": "TEST, RUN, TEST, UBNILAWE EKITI",
                    "Reference": "13352613"
                }
            ]
        },
        {
            "PersonalDetailsSummary": [
                {
                    "ConsumerID": "13352613",
                    "Header": "PERSONAL DETAILS SUMMARY: TEST RUN TEST",
                    "ReferenceNo": null,
                    "Nationality": "Nigeria",
                    "NationalIDNo": "",
                    "PassportNo": null,
                    "DriversLicenseNo": null,
                    "BankVerificationNo": "",
                    "PencomIDNo": "",
                    "OtheridNo": "",
                    "BirthDate": "12/12/1950",
                    "Dependants": "0",
                    "Gender": "Female",
                    "MaritalStatus": null,
                    "ResidentialAddress1": "UBNILAWE EKITI",
                    "ResidentialAddress2": "",
                    "ResidentialAddress3": "",
                    "ResidentialAddress4": "13 ",
                    "PostalAddress1": "UBNILAWE EKITI",
                    "PostalAddress2": "",
                    "PostalAddress3": "",
                    "PostalAddress4": "13 ",
                    "HomeTelephoneNo": null,
                    "WorkTelephoneNo": null,
                    "CellularNo": "",
                    "EmailAddress": "",
                    "EmployerDetail": null,
                    "PropertyOwnedType": "",
                    "Surname": "TEST",
                    "FirstName": "RUN",
                    "OtherNames": "TEST"
                }
            ]
        },
        {
            "DeliquencyInformation": [
                {
                    "SubscriberName": "",
                    "AccountNo": "",
                    "PeriodNum": "",
                    "MonthsinArrears": ""
                }
            ]
        },
        {
            "CreditAccountSummary": [
                {
                    "TotalMonthlyInstalment": "0.00",
                    "TotalOutstandingdebt": "1.00",
                    "TotalAccountarrear": "0",
                    "Amountarrear": "1.00",
                    "TotalAccounts": "2",
                    "TotalAccounts1": "0",
                    "TotalaccountinGodcondition": "1",
                    "TotalaccountinGoodcondition": "1",
                    "TotalNumberofJudgement": "0",
                    "TotalJudgementAmount": "0",
                    "LastJudgementDate": "-",
                    "TotalNumberofDishonoured": "0",
                    "TotalDishonouredAmount": "0.00",
                    "LastBouncedChequesDate": null,
                    "TotalMonthlyInstalment1": "0.00",
                    "TotalOutstandingdebt1": "0.00",
                    "TotalAccountarrear1": "0",
                    "Amountarrear1": "0.00",
                    "TotalaccountinGodcondition1": "0",
                    "TotalaccountinBadcondition": "0",
                    "TotalNumberofJudgement1": "0",
                    "TotalJudgementAmount1": "0",
                    "LastJudgementDate1": "-",
                    "TotalNumberofDishonoured1": "0",
                    "TotalDishonouredAmount1": "0.00",
                    "LastBouncedChequesDate1": null,
                    "Rating": "0"
                }
            ]
        },
        {
            "CreditAccountRating": [
                {
                    "NoOfHomeLoanAccountsGood": "0",
                    "NoOfHomeLoanAccountsBad": "0",
                    "NoOfAutoLoanccountsGood": "0",
                    "NoOfAutoLoanAccountsBad": "0",
                    "NoOfStudyLoanAccountsGood": "0",
                    "NoOfStudyLoanAccountsBad": "0",
                    "NoOfPersonalLoanAccountsGood": "0",
                    "NoOfPersonalLoanAccountsBad": "0",
                    "NoOfCreditCardAccountsGood": "0",
                    "NoOfCreditCardAccountsBad": "0",
                    "NoOfRetailAccountsGood": "0",
                    "NoOfRetailAccountsBad": "0",
                    "NoOfJointLoanAccountsGood": "0",
                    "NoOfJointLoanAccountsBad": "0",
                    "NoOfTelecomAccountsGood": "0",
                    "NoOfTelecomAccountsBad": "0",
                    "NoOfOtherAccountsGood": "1",
                    "NoOfOtherAccountsBad": "1"
                }
            ]
        },
        {
            "CreditAgreementSummary": [
                {
                    "DateAccountOpened": "19/06/2009",
                    "SubscriberName": "Union Bank Nigeria Plc Lagos",
                    "AccountNo": "000011111001",
                    "SubAccountNo": "",
                    "IndicatorDescription": null,
                    "OpeningBalanceAmt": "1.00",
                    "Currency": "NGN",
                    "CurrentBalanceDebitInd": "D",
                    "CurrentBalanceAmt": "1.00",
                    "InstalmentAmount": "0.00",
                    "AmountOverdue": "1.00",
                    "ClosedDate": null,
                    "LoanDuration": null,
                    "RepaymentFrequency": "Not Available",
                    "LastUpdatedDate": "22/10/2022",
                    "PerformanceStatus": "Doubtful",
                    "AccountStatus": "Closed"
                },
                {
                    "DateAccountOpened": "19/06/2009",
                    "SubscriberName": "Union Bank Nigeria Plc Lagos",
                    "AccountNo": "000011111001",
                    "SubAccountNo": "",
                    "IndicatorDescription": null,
                    "OpeningBalanceAmt": "1.00",
                    "Currency": "NGN",
                    "CurrentBalanceDebitInd": "D",
                    "CurrentBalanceAmt": "1.00",
                    "InstalmentAmount": "0.00",
                    "AmountOverdue": "1.00",
                    "ClosedDate": null,
                    "LoanDuration": null,
                    "RepaymentFrequency": "Not Available",
                    "LastUpdatedDate": "22/10/2022",
                    "PerformanceStatus": "Doubtful",
                    "AccountStatus": "Closed"
                }
            ]
        },
        {
            "AccountMonthlyPaymentHistoryHeader": [
                {
                    "TableName": "Consumer24MonthlyPaymentHeader",
                    "DisplayText": "Consumer 24 Monthly Payment Header",
                    "Company": "Company",
                    "MH24": "2021\nJUN",
                    "MH23": "2021\nJUL",
                    "MH22": "2021\nAUG",
                    "MH21": "2021\nSEP",
                    "MH20": "2021\nOCT",
                    "MH19": "2021\nNOV",
                    "MH18": "2021\nDEC",
                    "MH17": "2022\nJAN",
                    "MH16": "2022\nFEB",
                    "MH15": "2022\nMAR",
                    "MH14": "2022\nAPR",
                    "MH13": "2022\nMAY",
                    "MH12": "2022\nJUN",
                    "MH11": "2022\nJUL",
                    "MH10": "2022\nAUG",
                    "MH09": "2022\nSEP",
                    "MH08": "2022\nOCT",
                    "MH07": "2022\nNOV",
                    "MH06": "2022\nDEC",
                    "MH05": "2023\nJAN",
                    "MH04": "2023\nFEB",
                    "MH03": "2023\nMAR",
                    "MH02": "2023\nAPR",
                    "MH01": "2023\nMAY"
                },
                {
                    "TableName": "Consumer24MonthlyPaymentHeader",
                    "DisplayText": "Consumer 24 Monthly Payment Header",
                    "Company": "Company",
                    "MH24": "2021\nJUN",
                    "MH23": "2021\nJUL",
                    "MH22": "2021\nAUG",
                    "MH21": "2021\nSEP",
                    "MH20": "2021\nOCT",
                    "MH19": "2021\nNOV",
                    "MH18": "2021\nDEC",
                    "MH17": "2022\nJAN",
                    "MH16": "2022\nFEB",
                    "MH15": "2022\nMAR",
                    "MH14": "2022\nAPR",
                    "MH13": "2022\nMAY",
                    "MH12": "2022\nJUN",
                    "MH11": "2022\nJUL",
                    "MH10": "2022\nAUG",
                    "MH09": "2022\nSEP",
                    "MH08": "2022\nOCT",
                    "MH07": "2022\nNOV",
                    "MH06": "2022\nDEC",
                    "MH05": "2023\nJAN",
                    "MH04": "2023\nFEB",
                    "MH03": "2023\nMAR",
                    "MH02": "2023\nAPR",
                    "MH01": "2023\nMAY"
                }
            ]
        },
        {
            "AccountMonthlyPaymentHistory": [
                {
                    "Header": "Details of Credit Agreement with \"Union Bank Nigeria Plc Lagos\" for Account Number: 000011111001",
                    "TableName": "Consumer24MonthlyPayment",
                    "DisplayText": "Consumer 24 Monthly Payment",
                    "DateAccountOpened": "19/06/2009",
                    "SubscriberName": "Union Bank Nigeria Plc Lagos",
                    "AccountNo": "000011111001",
                    "SubAccountNo": "",
                    "Currency": "NGN",
                    "CurrentBalanceDebitInd": "D",
                    "IndicatorDescription": null,
                    "MonthlyInstalmentAmt": "1.00",
                    "LastPaymentDate": "01/01/1900",
                    "SubscriberTypeInd": "C",
                    "AccountNote": "",
                    "RepaymentFrequencyCode": "Not Available",
                    "OpeningBalanceAmt": "1.00",
                    "CurrentBalanceAmt": "0.00",
                    "AmountOverdue": "1.00",
                    "ClosedDate": null,
                    "LastUpdatedDate": "22/10/2022",
                    "PerformanceStatus": "Doubtful",
                    "LoanDuration": "Not Available",
                    "AccountStatus": "Closed",
                    "M01": "#",
                    "M02": "#",
                    "M03": "#",
                    "M04": "#",
                    "M05": "#",
                    "M06": "#",
                    "M07": "#",
                    "M08": "#",
                    "M09": "#",
                    "M10": "#",
                    "M11": "#",
                    "M12": "#",
                    "M13": "#",
                    "M14": "#",
                    "M15": "#",
                    "M16": "#",
                    "M17": "#",
                    "M18": "#",
                    "M19": "#",
                    "M20": "#",
                    "M21": "#",
                    "M22": "#",
                    "M23": "#",
                    "M24": "#"
                },
                {
                    "Header": "Details of Credit Agreement with \"Union Bank Nigeria Plc Lagos\" for Account Number: 0396100014406",
                    "TableName": "Consumer24MonthlyPayment",
                    "DisplayText": "Consumer 24 Monthly Payment",
                    "DateAccountOpened": "19/06/2009",
                    "SubscriberName": "Union Bank Nigeria Plc Lagos",
                    "AccountNo": "0396100014406",
                    "SubAccountNo": "",
                    "Currency": "NGN",
                    "CurrentBalanceDebitInd": "C",
                    "IndicatorDescription": null,
                    "MonthlyInstalmentAmt": "0.00",
                    "LastPaymentDate": "01/01/1900",
                    "SubscriberTypeInd": "C",
                    "AccountNote": "",
                    "RepaymentFrequencyCode": "Not Available",
                    "OpeningBalanceAmt": "1,000.00",
                    "CurrentBalanceAmt": "0.00",
                    "AmountOverdue": "0.00",
                    "ClosedDate": null,
                    "LastUpdatedDate": "26/09/2022",
                    "PerformanceStatus": "Performing",
                    "LoanDuration": "Not Available",
                    "AccountStatus": "Closed",
                    "M01": "#",
                    "M02": "#",
                    "M03": "#",
                    "M04": "#",
                    "M05": "#",
                    "M06": "#",
                    "M07": "#",
                    "M08": "#",
                    "M09": "#",
                    "M10": "#",
                    "M11": "#",
                    "M12": "#",
                    "M13": "#",
                    "M14": "#",
                    "M15": "#",
                    "M16": "#",
                    "M17": "#",
                    "M18": "#",
                    "M19": "#",
                    "M20": "#",
                    "M21": "#",
                    "M22": "#",
                    "M23": "#",
                    "M24": "#"
                }
            ]
        },
        {
            "GuarantorCount": [
                {
                    "GuarantorsSecured": "0",
                    "Accounts": "0"
                }
            ]
        },
        {
            "GuarantorDetails": [
                {
                    "GuarantorFirstName": "",
                    "GuarantorOtherName": "",
                    "GuarantorNationalIDNo": "",
                    "GuarantorPassport": "",
                    "GuarantorDriverLicenceNo": "",
                    "GuarantorPENCOMIDNo": "",
                    "GuarantorOtherID": "",
                    "GuarantorGender": "",
                    "GuarantorDateOfBirth": "",
                    "GuarantorAddress1": "",
                    "GuarantorAddress2": "",
                    "GuarantorAddress3": "",
                    "GuarantorHomeTelephone": "",
                    "GuarantorworkTelephone": "",
                    "GuarantorMobileTelephone": ""
                }
            ]
        },
        {
            "EnquiryHistoryTop": [
                {
                    "SubscriberEnquiryResultID": null,
                    "DateRequested": null,
                    "SubscriberName": null,
                    "EnquiryReason": null,
                    "CompanyTelephoneNo": null
                }
            ]
        },
        {
            "IdentificationHistory": [
                {
                    "UpDateDate": null,
                    "UpDateOnDate": null,
                    "IdentificationNumber": null,
                    "IdentificationType": null
                }
            ]
        },
        {
            "AddressHistory": [
                {
                    "UpDateDate": null,
                    "UpDateOnDate": null,
                    "Address1": null,
                    "Address2": null,
                    "Address3": null,
                    "Address4": null,
                    "AddressTypeInd": null
                }
            ]
        },
        {
            "EmploymentHistory": [
                {
                    "UpDateDate": null,
                    "UpDateOnDate": null,
                    "EmployerDetail": null,
                    "Occupation": null
                }
            ]
        },
        {
            "TelephoneHistory": []
        },
        {
            "EnquiryDetails": [
                {
                    "SubscriberEnquiryResultID": null,
                    "ProductID": null,
                    "MatchingRate": null,
                    "SubscriberEnquiryEngineID": null
                }
            ]
        }
    ]
 }
}

if(SubscriberEnquiryEngineID=='179065053' && EnquiryID=='60365779' && ConsumerID=='14713314')
{

    if(MergeList=='14713314' || MergeList=='')
    {
        recordsets = [
            {
                 //Hardcoded demo report
                "SubjectList": [
                    {
                        "ConsumerID": "14713314",
                        "SearchOutput": "TEST, RUN, , UBNILAWE EKITI",
                        "Reference": "14713314"
                    }
                ]
            },
            {
                "PersonalDetailsSummary": [
                    {
                        "ConsumerID": "14713314",
                        "Header": "PERSONAL DETAILS SUMMARY: TEST RUN ",
                        "ReferenceNo": null,
                        "Nationality": "NG",
                        "NationalIDNo": "",
                        "PassportNo": null,
                        "DriversLicenseNo": null,
                        "BankVerificationNo": "",
                        "PencomIDNo": "",
                        "OtheridNo": "",
                        "BirthDate": "12/12/1950",
                        "Dependants": "0",
                        "Gender": "Female",
                        "MaritalStatus": null,
                        "ResidentialAddress1": "UBNILAWE EKITI",
                        "ResidentialAddress2": "",
                        "ResidentialAddress3": "",
                        "ResidentialAddress4": "13 ",
                        "PostalAddress1": "UBNILAWE EKITI",
                        "PostalAddress2": "",
                        "PostalAddress3": "",
                        "PostalAddress4": "13 ",
                        "HomeTelephoneNo": null,
                        "WorkTelephoneNo": null,
                        "CellularNo": "",
                        "EmailAddress": "",
                        "EmployerDetail": null,
                        "PropertyOwnedType": "",
                        "Surname": "TEST",
                        "FirstName": "RUN",
                        "OtherNames": ""
                    }
                ]
            },
            {
                "DeliquencyInformation": [
                    {
                        "SubscriberName": "",
                        "AccountNo": "",
                        "PeriodNum": "",
                        "MonthsinArrears": ""
                    }
                ]
            },
            {
                "CreditAccountSummary": [
                    {
                        "TotalMonthlyInstalment": "0.00",
                        "TotalOutstandingdebt": "0.00",
                        "TotalAccountarrear": "0",
                        "Amountarrear": "0.00",
                        "TotalAccounts": "1",
                        "TotalAccounts1": "0",
                        "TotalaccountinGodcondition": "1",
                        "TotalaccountinGoodcondition": "1",
                        "TotalNumberofJudgement": "0",
                        "TotalJudgementAmount": "0",
                        "LastJudgementDate": "-",
                        "TotalNumberofDishonoured": "0",
                        "TotalDishonouredAmount": "0.00",
                        "LastBouncedChequesDate": null,
                        "TotalMonthlyInstalment1": "0.00",
                        "TotalOutstandingdebt1": "0.00",
                        "TotalAccountarrear1": "0",
                        "Amountarrear1": "0.00",
                        "TotalaccountinGodcondition1": "0",
                        "TotalaccountinBadcondition": "0",
                        "TotalNumberofJudgement1": "0",
                        "TotalJudgementAmount1": "0",
                        "LastJudgementDate1": "-",
                        "TotalNumberofDishonoured1": "0",
                        "TotalDishonouredAmount1": "0.00",
                        "LastBouncedChequesDate1": null,
                        "Rating": "0"
                    }
                ]
            },
            {
                "CreditAccountRating": [
                    {
                        "NoOfHomeLoanAccountsGood": "0",
                        "NoOfHomeLoanAccountsBad": "0",
                        "NoOfAutoLoanccountsGood": "0",
                        "NoOfAutoLoanAccountsBad": "0",
                        "NoOfStudyLoanAccountsGood": "0",
                        "NoOfStudyLoanAccountsBad": "0",
                        "NoOfPersonalLoanAccountsGood": "0",
                        "NoOfPersonalLoanAccountsBad": "0",
                        "NoOfCreditCardAccountsGood": "0",
                        "NoOfCreditCardAccountsBad": "0",
                        "NoOfRetailAccountsGood": "0",
                        "NoOfRetailAccountsBad": "0",
                        "NoOfJointLoanAccountsGood": "0",
                        "NoOfJointLoanAccountsBad": "0",
                        "NoOfTelecomAccountsGood": "0",
                        "NoOfTelecomAccountsBad": "0",
                        "NoOfOtherAccountsGood": "1",
                        "NoOfOtherAccountsBad": "0"
                    }
                ]
            },
            {
                "CreditAgreementSummary": [
                    {
                        "DateAccountOpened": "19/06/2009",
                        "SubscriberName": "Union Bank Nigeria Plc Lagos",
                        "AccountNo": "0396100014406",
                        "SubAccountNo": "",
                        "IndicatorDescription": null,
                        "OpeningBalanceAmt": "1,000.00",
                        "Currency": "NGN",
                        "CurrentBalanceDebitInd": "C",
                        "CurrentBalanceAmt": "0.00",
                        "InstalmentAmount": "0.00",
                        "AmountOverdue": "0.00",
                        "ClosedDate": null,
                        "LoanDuration": null,
                        "RepaymentFrequency": "Not Available",
                        "LastUpdatedDate": "26/09/2022",
                        "PerformanceStatus": "Performing",
                        "AccountStatus": "Closed"
                    }
                ]
            },
            {
                "AccountMonthlyPaymentHistoryHeader": [
                    {
                        "TableName": "Consumer24MonthlyPaymentHeader",
                        "DisplayText": "Consumer 24 Monthly Payment Header",
                        "Company": "Company",
                        "MH24": "2021\nJUN",
                        "MH23": "2021\nJUL",
                        "MH22": "2021\nAUG",
                        "MH21": "2021\nSEP",
                        "MH20": "2021\nOCT",
                        "MH19": "2021\nNOV",
                        "MH18": "2021\nDEC",
                        "MH17": "2022\nJAN",
                        "MH16": "2022\nFEB",
                        "MH15": "2022\nMAR",
                        "MH14": "2022\nAPR",
                        "MH13": "2022\nMAY",
                        "MH12": "2022\nJUN",
                        "MH11": "2022\nJUL",
                        "MH10": "2022\nAUG",
                        "MH09": "2022\nSEP",
                        "MH08": "2022\nOCT",
                        "MH07": "2022\nNOV",
                        "MH06": "2022\nDEC",
                        "MH05": "2023\nJAN",
                        "MH04": "2023\nFEB",
                        "MH03": "2023\nMAR",
                        "MH02": "2023\nAPR",
                        "MH01": "2023\nMAY"
                    }
                ]
            },
            {
                "AccountMonthlyPaymentHistory": [
                    {
                        "Header": "Details of Credit Agreement with \"Union Bank Nigeria Plc Lagos\" for Account Number: 0396100014406",
                        "TableName": "Consumer24MonthlyPayment",
                        "DisplayText": "Consumer 24 Monthly Payment",
                        "DateAccountOpened": "19/06/2009",
                        "SubscriberName": "Union Bank Nigeria Plc Lagos",
                        "AccountNo": "0396100014406",
                        "SubAccountNo": "",
                        "Currency": "NGN",
                        "CurrentBalanceDebitInd": "C",
                        "IndicatorDescription": null,
                        "MonthlyInstalmentAmt": "0.00",
                        "LastPaymentDate": "01/01/1900",
                        "SubscriberTypeInd": "C",
                        "AccountNote": "",
                        "RepaymentFrequencyCode": "Not Available",
                        "OpeningBalanceAmt": "1,000.00",
                        "CurrentBalanceAmt": "0.00",
                        "AmountOverdue": "0.00",
                        "ClosedDate": null,
                        "LastUpdatedDate": "26/09/2022",
                        "PerformanceStatus": "Performing",
                        "LoanDuration": "Not Available",
                        "AccountStatus": "Closed",
                        "M01": "#",
                        "M02": "#",
                        "M03": "#",
                        "M04": "#",
                        "M05": "#",
                        "M06": "#",
                        "M07": "#",
                        "M08": "#",
                        "M09": "#",
                        "M10": "#",
                        "M11": "#",
                        "M12": "#",
                        "M13": "#",
                        "M14": "#",
                        "M15": "#",
                        "M16": "#",
                        "M17": "#",
                        "M18": "#",
                        "M19": "#",
                        "M20": "#",
                        "M21": "#",
                        "M22": "#",
                        "M23": "#",
                        "M24": "#"
                    }
                ]
            },
            {
                "GuarantorCount": [
                    {
                        "GuarantorsSecured": "0",
                        "Accounts": "0"
                    }
                ]
            },
            {
                "GuarantorDetails": [
                    {
                        "GuarantorFirstName": "",
                        "GuarantorOtherName": "",
                        "GuarantorNationalIDNo": "",
                        "GuarantorPassport": "",
                        "GuarantorDriverLicenceNo": "",
                        "GuarantorPENCOMIDNo": "",
                        "GuarantorOtherID": "",
                        "GuarantorGender": "",
                        "GuarantorDateOfBirth": "",
                        "GuarantorAddress1": "",
                        "GuarantorAddress2": "",
                        "GuarantorAddress3": "",
                        "GuarantorHomeTelephone": "",
                        "GuarantorworkTelephone": "",
                        "GuarantorMobileTelephone": ""
                    }
                ]
            },
            {
                "EnquiryHistoryTop": [
                    {
                        "SubscriberEnquiryResultID": null,
                        "DateRequested": null,
                        "SubscriberName": null,
                        "EnquiryReason": null,
                        "CompanyTelephoneNo": null
                    }
                ]
            },
            {
                "IdentificationHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "IdentificationNumber": null,
                        "IdentificationType": null
                    }
                ]
            },
            {
                "AddressHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "Address1": null,
                        "Address2": null,
                        "Address3": null,
                        "Address4": null,
                        "AddressTypeInd": null
                    }
                ]
            },
            {
                "EmploymentHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "EmployerDetail": null,
                        "Occupation": null
                    }
                ]
            },
            {
                "TelephoneHistory": []
            },
            {
                "EnquiryDetails": [
                    {
                        "SubscriberEnquiryResultID": null,
                        "ProductID": null,
                        "MatchingRate": null,
                        "SubscriberEnquiryEngineID": null
                    }
                ]
            }
        ]
    }

    if(MergeList=='13352613,14713314' || MergeList=='14713314,13352613')
    {
        recordsets = [
            {
                 //Hardcoded demo report
                "SubjectList": [
                    {
                        "ConsumerID": "13352613",
                        "SearchOutput": "TEST, RUN, TEST, UBNILAWE EKITI",
                        "Reference": "13352613"
                    }
                ]
            },
            {
                "PersonalDetailsSummary": [
                    {
                        "ConsumerID": "13352613",
                        "Header": "PERSONAL DETAILS SUMMARY: TEST RUN TEST",
                        "ReferenceNo": null,
                        "Nationality": "Nigeria",
                        "NationalIDNo": "",
                        "PassportNo": null,
                        "DriversLicenseNo": null,
                        "BankVerificationNo": "",
                        "PencomIDNo": "",
                        "OtheridNo": "",
                        "BirthDate": "12/12/1950",
                        "Dependants": "0",
                        "Gender": "Female",
                        "MaritalStatus": null,
                        "ResidentialAddress1": "UBNILAWE EKITI",
                        "ResidentialAddress2": "",
                        "ResidentialAddress3": "",
                        "ResidentialAddress4": "13 ",
                        "PostalAddress1": "UBNILAWE EKITI",
                        "PostalAddress2": "",
                        "PostalAddress3": "",
                        "PostalAddress4": "13 ",
                        "HomeTelephoneNo": null,
                        "WorkTelephoneNo": null,
                        "CellularNo": "",
                        "EmailAddress": "",
                        "EmployerDetail": null,
                        "PropertyOwnedType": "",
                        "Surname": "TEST",
                        "FirstName": "RUN",
                        "OtherNames": "TEST"
                    }
                ]
            },
            {
                "DeliquencyInformation": [
                    {
                        "SubscriberName": "",
                        "AccountNo": "",
                        "PeriodNum": "",
                        "MonthsinArrears": ""
                    }
                ]
            },
            {
                "CreditAccountSummary": [
                    {
                        "TotalMonthlyInstalment": "0.00",
                        "TotalOutstandingdebt": "1.00",
                        "TotalAccountarrear": "0",
                        "Amountarrear": "1.00",
                        "TotalAccounts": "2",
                        "TotalAccounts1": "0",
                        "TotalaccountinGodcondition": "1",
                        "TotalaccountinGoodcondition": "1",
                        "TotalNumberofJudgement": "0",
                        "TotalJudgementAmount": "0",
                        "LastJudgementDate": "-",
                        "TotalNumberofDishonoured": "0",
                        "TotalDishonouredAmount": "0.00",
                        "LastBouncedChequesDate": null,
                        "TotalMonthlyInstalment1": "0.00",
                        "TotalOutstandingdebt1": "0.00",
                        "TotalAccountarrear1": "0",
                        "Amountarrear1": "0.00",
                        "TotalaccountinGodcondition1": "0",
                        "TotalaccountinBadcondition": "0",
                        "TotalNumberofJudgement1": "0",
                        "TotalJudgementAmount1": "0",
                        "LastJudgementDate1": "-",
                        "TotalNumberofDishonoured1": "0",
                        "TotalDishonouredAmount1": "0.00",
                        "LastBouncedChequesDate1": null,
                        "Rating": "0"
                    }
                ]
            },
            {
                "CreditAccountRating": [
                    {
                        "NoOfHomeLoanAccountsGood": "0",
                        "NoOfHomeLoanAccountsBad": "0",
                        "NoOfAutoLoanccountsGood": "0",
                        "NoOfAutoLoanAccountsBad": "0",
                        "NoOfStudyLoanAccountsGood": "0",
                        "NoOfStudyLoanAccountsBad": "0",
                        "NoOfPersonalLoanAccountsGood": "0",
                        "NoOfPersonalLoanAccountsBad": "0",
                        "NoOfCreditCardAccountsGood": "0",
                        "NoOfCreditCardAccountsBad": "0",
                        "NoOfRetailAccountsGood": "0",
                        "NoOfRetailAccountsBad": "0",
                        "NoOfJointLoanAccountsGood": "0",
                        "NoOfJointLoanAccountsBad": "0",
                        "NoOfTelecomAccountsGood": "0",
                        "NoOfTelecomAccountsBad": "0",
                        "NoOfOtherAccountsGood": "1",
                        "NoOfOtherAccountsBad": "1"
                    }
                ]
            },
            {
                "CreditAgreementSummary": [
                    {
                        "DateAccountOpened": "19/06/2009",
                        "SubscriberName": "Union Bank Nigeria Plc Lagos",
                        "AccountNo": "000011111001",
                        "SubAccountNo": "",
                        "IndicatorDescription": null,
                        "OpeningBalanceAmt": "1.00",
                        "Currency": "NGN",
                        "CurrentBalanceDebitInd": "D",
                        "CurrentBalanceAmt": "1.00",
                        "InstalmentAmount": "0.00",
                        "AmountOverdue": "1.00",
                        "ClosedDate": null,
                        "LoanDuration": null,
                        "RepaymentFrequency": "Not Available",
                        "LastUpdatedDate": "22/10/2022",
                        "PerformanceStatus": "Doubtful",
                        "AccountStatus": "Closed"
                    },
                    {
                        "DateAccountOpened": "19/06/2009",
                        "SubscriberName": "Union Bank Nigeria Plc Lagos",
                        "AccountNo": "000011111001",
                        "SubAccountNo": "",
                        "IndicatorDescription": null,
                        "OpeningBalanceAmt": "1.00",
                        "Currency": "NGN",
                        "CurrentBalanceDebitInd": "D",
                        "CurrentBalanceAmt": "1.00",
                        "InstalmentAmount": "0.00",
                        "AmountOverdue": "1.00",
                        "ClosedDate": null,
                        "LoanDuration": null,
                        "RepaymentFrequency": "Not Available",
                        "LastUpdatedDate": "22/10/2022",
                        "PerformanceStatus": "Doubtful",
                        "AccountStatus": "Closed"
                    }
                ]
            },
            {
                "AccountMonthlyPaymentHistoryHeader": [
                    {
                        "TableName": "Consumer24MonthlyPaymentHeader",
                        "DisplayText": "Consumer 24 Monthly Payment Header",
                        "Company": "Company",
                        "MH24": "2021\nJUN",
                        "MH23": "2021\nJUL",
                        "MH22": "2021\nAUG",
                        "MH21": "2021\nSEP",
                        "MH20": "2021\nOCT",
                        "MH19": "2021\nNOV",
                        "MH18": "2021\nDEC",
                        "MH17": "2022\nJAN",
                        "MH16": "2022\nFEB",
                        "MH15": "2022\nMAR",
                        "MH14": "2022\nAPR",
                        "MH13": "2022\nMAY",
                        "MH12": "2022\nJUN",
                        "MH11": "2022\nJUL",
                        "MH10": "2022\nAUG",
                        "MH09": "2022\nSEP",
                        "MH08": "2022\nOCT",
                        "MH07": "2022\nNOV",
                        "MH06": "2022\nDEC",
                        "MH05": "2023\nJAN",
                        "MH04": "2023\nFEB",
                        "MH03": "2023\nMAR",
                        "MH02": "2023\nAPR",
                        "MH01": "2023\nMAY"
                    },
                    {
                        "TableName": "Consumer24MonthlyPaymentHeader",
                        "DisplayText": "Consumer 24 Monthly Payment Header",
                        "Company": "Company",
                        "MH24": "2021\nJUN",
                        "MH23": "2021\nJUL",
                        "MH22": "2021\nAUG",
                        "MH21": "2021\nSEP",
                        "MH20": "2021\nOCT",
                        "MH19": "2021\nNOV",
                        "MH18": "2021\nDEC",
                        "MH17": "2022\nJAN",
                        "MH16": "2022\nFEB",
                        "MH15": "2022\nMAR",
                        "MH14": "2022\nAPR",
                        "MH13": "2022\nMAY",
                        "MH12": "2022\nJUN",
                        "MH11": "2022\nJUL",
                        "MH10": "2022\nAUG",
                        "MH09": "2022\nSEP",
                        "MH08": "2022\nOCT",
                        "MH07": "2022\nNOV",
                        "MH06": "2022\nDEC",
                        "MH05": "2023\nJAN",
                        "MH04": "2023\nFEB",
                        "MH03": "2023\nMAR",
                        "MH02": "2023\nAPR",
                        "MH01": "2023\nMAY"
                    }
                ]
            },
            {
                "AccountMonthlyPaymentHistory": [
                    {
                        "Header": "Details of Credit Agreement with \"Union Bank Nigeria Plc Lagos\" for Account Number: 000011111001",
                        "TableName": "Consumer24MonthlyPayment",
                        "DisplayText": "Consumer 24 Monthly Payment",
                        "DateAccountOpened": "19/06/2009",
                        "SubscriberName": "Union Bank Nigeria Plc Lagos",
                        "AccountNo": "000011111001",
                        "SubAccountNo": "",
                        "Currency": "NGN",
                        "CurrentBalanceDebitInd": "D",
                        "IndicatorDescription": null,
                        "MonthlyInstalmentAmt": "1.00",
                        "LastPaymentDate": "01/01/1900",
                        "SubscriberTypeInd": "C",
                        "AccountNote": "",
                        "RepaymentFrequencyCode": "Not Available",
                        "OpeningBalanceAmt": "1.00",
                        "CurrentBalanceAmt": "0.00",
                        "AmountOverdue": "1.00",
                        "ClosedDate": null,
                        "LastUpdatedDate": "22/10/2022",
                        "PerformanceStatus": "Doubtful",
                        "LoanDuration": "Not Available",
                        "AccountStatus": "Closed",
                        "M01": "#",
                        "M02": "#",
                        "M03": "#",
                        "M04": "#",
                        "M05": "#",
                        "M06": "#",
                        "M07": "#",
                        "M08": "#",
                        "M09": "#",
                        "M10": "#",
                        "M11": "#",
                        "M12": "#",
                        "M13": "#",
                        "M14": "#",
                        "M15": "#",
                        "M16": "#",
                        "M17": "#",
                        "M18": "#",
                        "M19": "#",
                        "M20": "#",
                        "M21": "#",
                        "M22": "#",
                        "M23": "#",
                        "M24": "#"
                    },
                    {
                        "Header": "Details of Credit Agreement with \"Union Bank Nigeria Plc Lagos\" for Account Number: 0396100014406",
                        "TableName": "Consumer24MonthlyPayment",
                        "DisplayText": "Consumer 24 Monthly Payment",
                        "DateAccountOpened": "19/06/2009",
                        "SubscriberName": "Union Bank Nigeria Plc Lagos",
                        "AccountNo": "0396100014406",
                        "SubAccountNo": "",
                        "Currency": "NGN",
                        "CurrentBalanceDebitInd": "C",
                        "IndicatorDescription": null,
                        "MonthlyInstalmentAmt": "0.00",
                        "LastPaymentDate": "01/01/1900",
                        "SubscriberTypeInd": "C",
                        "AccountNote": "",
                        "RepaymentFrequencyCode": "Not Available",
                        "OpeningBalanceAmt": "1,000.00",
                        "CurrentBalanceAmt": "0.00",
                        "AmountOverdue": "0.00",
                        "ClosedDate": null,
                        "LastUpdatedDate": "26/09/2022",
                        "PerformanceStatus": "Performing",
                        "LoanDuration": "Not Available",
                        "AccountStatus": "Closed",
                        "M01": "#",
                        "M02": "#",
                        "M03": "#",
                        "M04": "#",
                        "M05": "#",
                        "M06": "#",
                        "M07": "#",
                        "M08": "#",
                        "M09": "#",
                        "M10": "#",
                        "M11": "#",
                        "M12": "#",
                        "M13": "#",
                        "M14": "#",
                        "M15": "#",
                        "M16": "#",
                        "M17": "#",
                        "M18": "#",
                        "M19": "#",
                        "M20": "#",
                        "M21": "#",
                        "M22": "#",
                        "M23": "#",
                        "M24": "#"
                    }
                ]
            },
            {
                "GuarantorCount": [
                    {
                        "GuarantorsSecured": "0",
                        "Accounts": "0"
                    }
                ]
            },
            {
                "GuarantorDetails": [
                    {
                        "GuarantorFirstName": "",
                        "GuarantorOtherName": "",
                        "GuarantorNationalIDNo": "",
                        "GuarantorPassport": "",
                        "GuarantorDriverLicenceNo": "",
                        "GuarantorPENCOMIDNo": "",
                        "GuarantorOtherID": "",
                        "GuarantorGender": "",
                        "GuarantorDateOfBirth": "",
                        "GuarantorAddress1": "",
                        "GuarantorAddress2": "",
                        "GuarantorAddress3": "",
                        "GuarantorHomeTelephone": "",
                        "GuarantorworkTelephone": "",
                        "GuarantorMobileTelephone": ""
                    }
                ]
            },
            {
                "EnquiryHistoryTop": [
                    {
                        "SubscriberEnquiryResultID": null,
                        "DateRequested": null,
                        "SubscriberName": null,
                        "EnquiryReason": null,
                        "CompanyTelephoneNo": null
                    }
                ]
            },
            {
                "IdentificationHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "IdentificationNumber": null,
                        "IdentificationType": null
                    }
                ]
            },
            {
                "AddressHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "Address1": null,
                        "Address2": null,
                        "Address3": null,
                        "Address4": null,
                        "AddressTypeInd": null
                    }
                ]
            },
            {
                "EmploymentHistory": [
                    {
                        "UpDateDate": null,
                        "UpDateOnDate": null,
                        "EmployerDetail": null,
                        "Occupation": null
                    }
                ]
            },
            {
                "TelephoneHistory": []
            },
            {
                "EnquiryDetails": [
                    {
                        "SubscriberEnquiryResultID": null,
                        "ProductID": null,
                        "MatchingRate": null,
                        "SubscriberEnquiryEngineID": null
                    }
                ]
            }
        ]
    
    }

}

            return recordsets;
        } 
}

module.exports = new matchMssql();