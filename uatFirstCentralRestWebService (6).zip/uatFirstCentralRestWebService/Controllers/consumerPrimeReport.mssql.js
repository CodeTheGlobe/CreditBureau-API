// const mssql = require('mssql');
// const mssqlcon = require("../Config");



class matchMssql {
    async consumerPrimeReport(req, res, decodedObj) {
        const RealProductID = 50;
        const EnquiryInput = [];
        const Report = 'Xscore Consumer Full Credit Report';
        // const conn = await mssqlcon.getConnection();


            const SubscriberEnquiryEngineID = req.subscriberenquiryengineid;
            const EnquiryID = req.enquiryid;
            const ConsumerID = req.consumerid;
            const MergeList = req.consumermergelist;
            let recordsets = [];

            
if(SubscriberEnquiryEngineID=='179064971' && EnquiryID=='60365700' && ConsumerID=='2599049')
{
             recordsets = [
                {
                     //Hardcoded demo report
                    "SubjectList": [
                        {
                            "ConsumerID": "2599049",
                            "SearchOutput": "UMORU, MUHAMMED, , PrimaryAddressLine1",
                            "Reference": "2599049"
                        }
                    ]
                },
                {
                    "PersonalDetailsSummary": [
                        {
                            "ConsumerID": "2599049",
                            "Header": "PERSONAL DETAILS SUMMARY: Amos Testi ",
                            "ReferenceNo": null,
                            "Nationality": "Nigeria",
                            "NationalIDNo": "",
                            "PassportNo": null,
                            "DriversLicenseNo": null,
                            "BankVerificationNo": "22471069115",
                            "PencomIDNo": "",
                            "OtheridNo": "",
                            "BirthDate": "26/01/1977",
                            "Dependants": "0",
                            "Gender": "Female",
                            "MaritalStatus": null,
                            "ResidentialAddress1": "College Road Abaro Aladje",
                            "ResidentialAddress2": "Delta",
                            "ResidentialAddress3": "",
                            "ResidentialAddress4": " ",
                            "PostalAddress1": null,
                            "PostalAddress2": null,
                            "PostalAddress3": null,
                            "PostalAddress4": null,
                            "HomeTelephoneNo": null,
                            "WorkTelephoneNo": null,
                            "CellularNo": "",
                            "EmailAddress": "",
                            "EmployerDetail": null,
                            "PropertyOwnedType": "",
                            "Surname": "Amos",
                            "FirstName": "Testi",
                            "OtherNames": ""
                        }
                    ]
                },
                {
                    "CreditSummary": [
                        {
                            "TotalNumberOfAccountsReported": "6",
                            "NumberOfAccountsInGoodStanding": "6",
                            "NumberofAccountsInBadStanding": "0"
                        }
                    ]
                },
                {
                    "PerformanceClassification": [
                        {
                            "NoOfLoansPerforming": "6",
                            "NoOfLoansSubstandard": "0",
                            "NoOfLoansDoubtful": "0",
                            "NoOfLoansLost": "0"
                        }
                    ]
                },
                {
                    "EnquiryDetails": [
                        {
                            "SubscriberEnquiryResultID": null,
                            "ProductID": null,
                            "MatchingRate": null,
                            "SubscriberEnquiryEngineID": null
                        }
                    ]
                }
            ]
 }



     
if(SubscriberEnquiryEngineID=='179065053' && EnquiryID=='60365779' && ConsumerID=='13352613')
{

if(MergeList=='13352613' || MergeList=='')
{
    recordsets = [
        {
             //Hardcoded demo report
            "SubjectList": [
                {
                    "ConsumerID": "13352613",
                    "SearchOutput": "UMORU, MUHAMMED, , PrimaryAddressLine1",
                    "Reference": "13352613"
                }
            ]
        },
        {
            "PersonalDetailsSummary": [
                {
                    "ConsumerID": "13352613",
                    "Header": "PERSONAL DETAILS SUMMARY: TEST RUN TEST",
                    "ReferenceNo": null,
                    "Nationality": "Nigeria",
                    "NationalIDNo": "",
                    "PassportNo": null,
                    "DriversLicenseNo": null,
                    "BankVerificationNo": "",
                    "PencomIDNo": "",
                    "OtheridNo": "",
                    "BirthDate": "12/12/1950",
                    "Dependants": "0",
                    "Gender": "Female",
                    "MaritalStatus": null,
                    "ResidentialAddress1": "UBNILAWE EKITI",
                    "ResidentialAddress2": "",
                    "ResidentialAddress3": "",
                    "ResidentialAddress4": "13 ",
                    "PostalAddress1": "UBNILAWE EKITI",
                    "PostalAddress2": "",
                    "PostalAddress3": "",
                    "PostalAddress4": "13 ",
                    "HomeTelephoneNo": null,
                    "WorkTelephoneNo": null,
                    "CellularNo": "",
                    "EmailAddress": "",
                    "EmployerDetail": null,
                    "PropertyOwnedType": "",
                    "Surname": "TEST",
                    "FirstName": "RUN",
                    "OtherNames": "TEST"
                }
            ]
        },
        {
            "CreditSummary": [
                {
                    "TotalNumberOfAccountsReported": "6",
                    "NumberOfAccountsInGoodStanding": "6",
                    "NumberofAccountsInBadStanding": "0"
                }
            ]
        },
        {
            "PerformanceClassification": [
                {
                    "NoOfLoansPerforming": "6",
                    "NoOfLoansSubstandard": "0",
                    "NoOfLoansDoubtful": "0",
                    "NoOfLoansLost": "0"
                }
            ]
        },
        {
            "EnquiryDetails": [
                {
                    "SubscriberEnquiryResultID": null,
                    "ProductID": null,
                    "MatchingRate": null,
                    "SubscriberEnquiryEngineID": null
                }
            ]
        }
    ]

 }

 if(MergeList=='13352613,14713314' || MergeList=='14713314,13352613')
{
    recordsets = [
        {
             //Hardcoded demo report
            "SubjectList": [
                {
                    "ConsumerID": "13352613",
                    "SearchOutput": "TEST, RUN, TEST, UBNILAWE EKITI",
                    "Reference": "13352613"
                },
                {
                    "ConsumerID": "14713314",
                    "SearchOutput": "TEST, RUN, , UBNILAWE EKITI",
                    "Reference": "14713314"
                }
            ]
        },
        {
            "PersonalDetailsSummary": [
                {
                    "ConsumerID": "14713314",
                    "Header": "PERSONAL DETAILS SUMMARY: TEST RUN ",
                    "ReferenceNo": null,
                    "Nationality": "NG",
                    "NationalIDNo": "",
                    "PassportNo": null,
                    "DriversLicenseNo": null,
                    "BankVerificationNo": "",
                    "PencomIDNo": "",
                    "OtheridNo": "",
                    "BirthDate": "12/12/1950",
                    "Dependants": "0",
                    "Gender": "Female",
                    "MaritalStatus": null,
                    "ResidentialAddress1": "UBNILAWE EKITI",
                    "ResidentialAddress2": "",
                    "ResidentialAddress3": "",
                    "ResidentialAddress4": "13 ",
                    "PostalAddress1": "UBNILAWE EKITI",
                    "PostalAddress2": "",
                    "PostalAddress3": "",
                    "PostalAddress4": "13 ",
                    "HomeTelephoneNo": null,
                    "WorkTelephoneNo": null,
                    "CellularNo": "",
                    "EmailAddress": "",
                    "EmployerDetail": null,
                    "PropertyOwnedType": "",
                    "Surname": "TEST",
                    "FirstName": "RUN",
                    "OtherNames": ""
                }
            ]
        },
        {
            "CreditSummary": [
                {
                    "TotalNumberOfAccountsReported": "2",
                    "NumberOfAccountsInGoodStanding": "2",
                    "NumberofAccountsInBadStanding": "0"
                }
            ]
        },
        {
            "PerformanceClassification": [
                {
                    "NoOfLoansPerforming": "2",
                    "NoOfLoansSubstandard": "0",
                    "NoOfLoansDoubtful": "1",
                    "NoOfLoansLost": "0"
                }
            ]
        },
        {
            "EnquiryDetails": [
                {
                    "SubscriberEnquiryResultID": null,
                    "ProductID": null,
                    "MatchingRate": null,
                    "SubscriberEnquiryEngineID": null
                }
            ]
        }
    ]
 }
}

if(SubscriberEnquiryEngineID=='179065053' && EnquiryID=='60365779' && ConsumerID=='14713314')
{

    if(MergeList=='14713314' || MergeList=='')
    {
        recordsets = [
            {
                 //Hardcoded demo report
                "SubjectList": [
                    {
                        "ConsumerID": "14713314",
                        "SearchOutput": "UMORU, MUHAMMED, , PrimaryAddressLine1",
                        "Reference": "14713314"
                    }
                ]
            },
            {
                "PersonalDetailsSummary": [
                    {
                        "ConsumerID": "14713314",
                        "Header": "PERSONAL DETAILS SUMMARY: TEST RUN ",
                        "ReferenceNo": null,
                        "Nationality": "NG",
                        "NationalIDNo": "",
                        "PassportNo": null,
                        "DriversLicenseNo": null,
                        "BankVerificationNo": "",
                        "PencomIDNo": "",
                        "OtheridNo": "",
                        "BirthDate": "12/12/1950",
                        "Dependants": "0",
                        "Gender": "Female",
                        "MaritalStatus": null,
                        "ResidentialAddress1": "UBNILAWE EKITI",
                        "ResidentialAddress2": "",
                        "ResidentialAddress3": "",
                        "ResidentialAddress4": "13 ",
                        "PostalAddress1": "UBNILAWE EKITI",
                        "PostalAddress2": "",
                        "PostalAddress3": "",
                        "PostalAddress4": "13 ",
                        "HomeTelephoneNo": null,
                        "WorkTelephoneNo": null,
                        "CellularNo": "",
                        "EmailAddress": "",
                        "EmployerDetail": null,
                        "PropertyOwnedType": "",
                        "Surname": "TEST",
                        "FirstName": "RUN",
                        "OtherNames": ""
                    }
                ]
            },
            {
                "CreditSummary": [
                    {
                        "TotalNumberOfAccountsReported": "6",
                        "NumberOfAccountsInGoodStanding": "6",
                        "NumberofAccountsInBadStanding": "0"
                    }
                ]
            },
            {
                "PerformanceClassification": [
                    {
                        "NoOfLoansPerforming": "6",
                        "NoOfLoansSubstandard": "0",
                        "NoOfLoansDoubtful": "0",
                        "NoOfLoansLost": "0"
                    }
                ]
            },
            {
                "EnquiryDetails": [
                    {
                        "SubscriberEnquiryResultID": null,
                        "ProductID": null,
                        "MatchingRate": null,
                        "SubscriberEnquiryEngineID": null
                    }
                ]
            }
        ]
    }

    if(MergeList=='13352613,14713314' || MergeList=='14713314,13352613')
    {
        recordsets = [
            {
                 //Hardcoded demo report
                "SubjectList": [
                    {
                        "ConsumerID": "13352613",
                        "SearchOutput": "TEST, RUN, TEST, UBNILAWE EKITI",
                        "Reference": "13352613"
                    },
                    {
                        "ConsumerID": "14713314",
                        "SearchOutput": "TEST, RUN, , UBNILAWE EKITI",
                        "Reference": "14713314"
                    }
                ]
            },
            {
                "PersonalDetailsSummary": [
                    {
                        "ConsumerID": "14713314",
                        "Header": "PERSONAL DETAILS SUMMARY: TEST RUN ",
                        "ReferenceNo": null,
                        "Nationality": "NG",
                        "NationalIDNo": "",
                        "PassportNo": null,
                        "DriversLicenseNo": null,
                        "BankVerificationNo": "",
                        "PencomIDNo": "",
                        "OtheridNo": "",
                        "BirthDate": "12/12/1950",
                        "Dependants": "0",
                        "Gender": "Female",
                        "MaritalStatus": null,
                        "ResidentialAddress1": "UBNILAWE EKITI",
                        "ResidentialAddress2": "",
                        "ResidentialAddress3": "",
                        "ResidentialAddress4": "13 ",
                        "PostalAddress1": "UBNILAWE EKITI",
                        "PostalAddress2": "",
                        "PostalAddress3": "",
                        "PostalAddress4": "13 ",
                        "HomeTelephoneNo": null,
                        "WorkTelephoneNo": null,
                        "CellularNo": "",
                        "EmailAddress": "",
                        "EmployerDetail": null,
                        "PropertyOwnedType": "",
                        "Surname": "TEST",
                        "FirstName": "RUN",
                        "OtherNames": ""
                    }
                ]
            },
         
            {
                "CreditSummary": [
                    {
                        "TotalNumberOfAccountsReported": "2",
                        "NumberOfAccountsInGoodStanding": "2",
                        "NumberofAccountsInBadStanding": "0"
                    }
                ]
            },
            {
                "PerformanceClassification": [
                    {
                        "NoOfLoansPerforming": "2",
                        "NoOfLoansSubstandard": "0",
                        "NoOfLoansDoubtful": "1",
                        "NoOfLoansLost": "0"
                    }
                ]
            },
            {
                "EnquiryDetails": [
                    {
                        "SubscriberEnquiryResultID": null,
                        "ProductID": null,
                        "MatchingRate": null,
                        "SubscriberEnquiryEngineID": null
                    }
                ]
            }
        ]
    
    }

}
        return recordsets;

        } 
}

module.exports = new matchMssql();