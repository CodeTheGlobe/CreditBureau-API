'use strict';
var debug = require('debug')('my express app');
var express = require('express');
var path = require('path');
//var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var route = require('./routes/index');
var route2 = require('./routes/index2');
var route3 = require('./routes/index3');
var route4 = require('./routes/index4');
var route5 = require('./routes/index5');
var route6 = require('./routes/index6');
var route7 = require('./routes/index7');
var route8 = require('./routes/index8');
var route9 = require('./routes/index9');
var route10 = require('./routes/index10');
var route11 = require('./routes/index11');
var route12 = require('./routes/index12');
var route13 = require('./routes/index13');
var route14 = require('./routes/index14');
var route15 = require('./routes/index15');
var route16 = require('./routes/index16');
var route17 = require('./routes/index17');
var route18 = require('./routes/index18');
var route19 = require('./routes/index19');
var route20 = require('./routes/index20');
var route21 = require('./routes/index21');
var route22 = require('./routes/index22');
var route23 = require('./routes/index23');

var app = express();

//app.get('/firstcentralrest/express/myapp', function (req, res) {
//    res.send('Hello from food! [express sample]');
//});

// view engine setup
// app.set('views', path.join(__dirname, 'views'));
// app.set('view engine', 'pug');

app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');

// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/firstcentralrestv2', route);
app.use('/firstcentralrestv2/login', route2);
app.use('/firstcentralrestv2/connectconsumermatch/', route3);
app.use('/firstcentralrestv2/consumerFullCredit', route4);
app.use('/firstcentralrestv2/getconsumerFullCreditreport', route4);

app.use('/firstcentralrestv2/consumerBasicCredit', route5);
app.use('/firstcentralrestv2/getconsumerBasicCreditreport', route5);

app.use('/firstcentralrestv2/consumerBasicCreditBinary', route17);
app.use('/firstcentralrestv2/getconsumerBasicCreditBinaryreport', route17);

app.use('/firstcentralrestv2/consumerPrime', route6);
app.use('/firstcentralrestv2/consumerPrimereport', route6);

// app.use('/firstcentralrestv2/consumerPrimeReportBinary', route6);
app.use('/firstcentralrestv2/KYCWithBVNOut', route7);
app.use('/firstcentralrestv2/GetConsumerKYCVerificationReport', route7);

app.use('/firstcentralrestv2/xscoreconsumerFullCredit', route8);
app.use('/firstcentralrestv2/getxscoreconsumerFullCreditreport', route8);

app.use('/firstcentralrestv2/xscoreconsumerFullCreditBinary', route16);
app.use('/firstcentralrestv2/getxscoreconsumerFullCreditBinaryreport', route16);

app.use('/firstcentralrestv2/connectcommercialmatch', route9);
app.use('/firstcentralrestv2/connectcommercialmatch', route9);

app.use('/firstcentralrestv2/commercialFullCredit', route10);
app.use('/firstcentralrestv2/getcommercialFullCreditreport', route10);

app.use('/firstcentralrestv2/commercialBasicReport', route11);
app.use('/firstcentralrestv2/getcommercialBasicReport', route11);
app.use('/firstcentralrestv2/commercialBasicCredit', route11);
app.use('/firstcentralrestv2/getcommercialBasicCreditReport', route11);


// app.use('/firstcentralrestv2/commercialBasicReportBinary', route12);
app.use('/firstcentralrestv2/commercialFullCreditBinary', route15);
app.use('/firstcentralrestv2/GetcommercialFullCreditBinaryreport', route15);

app.use('/firstcentralrestv2/isTicketValid', route13);
app.use('/firstcentralrestv2/validateTicket', route13);

app.use('/firstcentralrestv2/consumerFullCreditBinary', route14);
app.use('/firstcentralrestv2/getconsumerFullCreditBinaryreport', route14);

app.use('/firstcentralrestv2/iScoreBinary', route18);//
app.use('/firstcentralrestv2/getiScoreBinaryreport', route18);//

app.use('/firstcentralrestv2/xscoreConsumerPrimeReport', route19);//
app.use('/firstcentralrestv2/getxscoreConsumerPrimeReport', route19);//

app.use('/firstcentralrestv2/iScore', route20);
app.use('/firstcentralrestv2/getiScorereport', route20);

app.use('/firstcentralrestv2/consumerBasicTrace', route21);
app.use('/firstcentralrestv2/getconsumerBasicTracereport', route21);

app.use('/firstcentralrestv2/consumerreports', route22);
app.use('/firstcentralrestv2/getconsumerreports', route22);

app.use('/firstcentralrestv2/commercialreports', route23);
app.use('/firstcentralrestv2/getcommercialreports', route23);
// app.use('/firstcentralrestv2/commercialPrimeReport', route24);


//app.use('/xscorecommercialFullCreditReport', routes12);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});


// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(function (error, req, res, next) {
        const err = error?.status || 500;
        //console.log(error)
        res.status(err).json({
            status: err,
            message: error?.message || 'Server Error',
            
        })
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function (error, req, res, next) {
    const err = error?.status || 500;
    res.status(err).json({
        status: err,
        message: error?.message || 'Server Error'
    })
});

app.set('port', process.env.PORT || 3015);
//app.set('port', process.env.PORT);

var server = app.listen(app.get('port'), function () {
    debug('Express server listening on port ' + server.address().port);
console.log(server.address().port);
});


