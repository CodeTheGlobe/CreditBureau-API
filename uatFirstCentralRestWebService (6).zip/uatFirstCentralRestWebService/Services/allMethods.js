var jwt = require('jsonwebtoken');
const loginMssql = require("../Controllers/login.mssql");
const matchMssql = require("../Controllers/consumermatch.mssql");
const consumerFullCreditMssql = require("../Controllers/consumerFullCreditReport.mssql");
const consumerFullCreditBinaryMssql = require("../Controllers/consumerFullCreditReportBinary.mssql");
const consumerBasicMssql = require("../Controllers/consumerBasicReport.mssql");
const consumerBasicReportMssql = require("../Controllers/consumerBasicReportBinary.mssql");
const consumerPrimeMssql = require("../Controllers/consumerPrimeReport.mssql");
const consumerKYCVerificationMssql = require("../Controllers/consumerKYCVerificationReport.mssql");
const XscoreConsumerFullCreditMssql = require("../Controllers/XscoreConsumerFullCreditReport.mssql");
const XscoreConsumerPrimeReportMssql = require("../Controllers/XscoreConsumerPrimeReport.mssql");
const ConsumerBasicTraceReportMssql = require("../Controllers/ConsumerBasicTraceReport.mssql");
const iScoreReportMssql = require("../Controllers/iScoreReport.mssql");
const iScoreReportBinaryMssql = require("../Controllers/iScoreReportBinary.mssql");
const XscoreConsumerFullCreditBinaryMssql = require("../Controllers/XscoreConsumerFullCreditReportBinary.mssql");

//environment variable is used in production 
var secretKey = 'ipasihtgnitset'
var decodedObj;

function convertObjectToLowerCase(obj) {
    if (typeof obj !== 'object' || obj === null) {
        return obj;
      }
  
    const converted = {};
    for (const key in obj) {
        const convertedKey = key.toLowerCase();
        const value = obj[key];
        const convertedValue = convertObjectToLowerCase(value);
        converted[convertedKey] = convertedValue;
      }
  
    return converted;
  }

class consumer {
    async getTicket(req, res, next) {
        try {
            

            const newObject = convertObjectToLowerCase(req.body);
            const output = await loginMssql.getTicket(newObject, res);
            
            //Generate ticket using secret key and set expiry to 5 hours
            jwt.sign(output, secretKey, { expiresIn: 18000000 }, function (err, token) {
                if (err) {
                    res.json(err.message);
                }
                res.json([{"DataTicket":token}]);

            })
            
        }
        catch (error) {
            next(error)
        }
    }


    //Verify ticket validity
    async isTicketValid(req, res, next) {
        try {

            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                res.json({"status":"True"}); 
            });
            
        }
        catch (error) {
            next(error)
        }
    }



//To know service is available
    async getSample(req, res) {

            res.json({"Message": "Web service is active"});

             }


    //Serach for customer using ID number
    async matchMssql(req, res, next) {
        try {

            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }
                
                    decodedObj = decoded; // bar
            });

            const output = await matchMssql.consumermatch(newObject, res, decodedObj);
            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }


    //------------------------------------------Report section Begins----------------------------------------------------------


    async consumerFullCreditMssql(req, res, next) {
        try {
            
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await consumerFullCreditMssql.consumerfullCredit(newObject, res, decodedObj);
         
            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }


    async consumerFullCreditBinaryMssql(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await consumerFullCreditBinaryMssql.consumerfullCreditBinary(newObject, res, decodedObj);

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }


    async consumerBasicReportBinaryMssql(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await consumerBasicReportMssql.consumerBasicReportBinary(newObject, res, decodedObj);
         
            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }


    async consumerBasicReportMssql(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await consumerBasicMssql.consumerBasicReport(newObject, res, decodedObj);

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }

    

    async consumerPrimeReportMssql(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await consumerPrimeMssql.consumerPrimeReport(newObject, res, decodedObj);
         
            res.json(output);
        }
        catch (error) {
            console.log(error);
        }
    }

    async consumerKYCVerificationReport(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await consumerKYCVerificationMssql.consumerKYCVerificationReport(newObject, res, decodedObj);
         
            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }

    

    async xscoreConsumerFullCreditReport(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await XscoreConsumerFullCreditMssql.XscoreConsumerFullCreditReport(newObject, res, decodedObj);
         
            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }


    async iScoreReport(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await iScoreReportMssql.iScoreReport(newObject, res, decodedObj);

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }


    async iScoreReportBinary(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await iScoreReportBinaryMssql.iScoreReportBinary(newObject, res, decodedObj);

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }



    async ConsumerBasicTraceReport(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await ConsumerBasicTraceReportMssql.ConsumerBasicTraceReport(newObject, res, decodedObj);

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }


    async XscoreConsumerPrimeReport(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await XscoreConsumerPrimeReportMssql.XscoreConsumerPrimeReport(newObject, res, decodedObj);

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }


    async xscoreConsumerFullCreditReportBinary(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await XscoreConsumerFullCreditBinaryMssql.XscoreConsumerFullCreditReportBinary(newObject, res, decodedObj);

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }

    
    async reports(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            let output = {};
         

            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            if(newObject.productid == 44) {
            output = await consumerBasicMssql.consumerBasicReport(newObject, res, decodedObj);
            
            }
            else if(newObject.productid == 43) {
                output = await consumerBasicTraceMssql.consumerBasicTrace(newObject, res, decodedObj);
                
            }
            else if(newObject.productid == 50) {
                output = await XscoreConsumerFullCreditMssql.XscoreConsumerFullCreditReport(newObject, res, decodedObj);
                
            }
            else if(newObject.productid == 63) {
                output = await consumerPrimeMssql.consumerPrimeReport(newObject, res, decodedObj);
                
            }
            else if(newObject.productid == 70) {
                output = await iScoreMssql.iScore(newObject, res, decodedObj);
                
            }
            else if(newObject.productid == 64) {
                output = await xscoreConsumerPrimeMssql.xscoreConsumerPrimeReport(newObject, res, decodedObj);
                
            }
            else if(newObject.productid == 45) {
                output = await consumerFullCreditMssql.consumerfullCredit(newObject, res, decodedObj);
                
            }
            else if(newObject.productid == 66) {
                output = await consumerKYCVerificationMssql.consumerKYCVerificationReport(newObject, res, decodedObj);
                
            }
            else  {
               output={Error:"You entered a wrong productID"}
                
            }
         
            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }

    //-----------------------------------------Report section Ends------------------------------------------------------------


}
module.exports = new consumer();