var jwt = require('jsonwebtoken');
const loginMssql = require("../Controllers/login.mssql");
const matchMssql = require("../Controllers/commercialmatch.mssql");
const commercialFullCreditMssql = require("../Controllers/commercialFullCreditReport.mssql");
const commercialFullCreditBinaryMssql = require("../Controllers/commercialFullCreditReportBinary.mssql");
const commercialBasicReportMssql = require("../Controllers/commercialBasicReport.mssql");
const commercialBasicReportBinaryMssql = require("../Controllers/commercialBasicReportBinary.mssql");
//const commercialPrimeMssql = require("../Controllers/commercialPrimeReport.mssql");

var secretKey = 'ipasihtgnitset'
var decodedObj;

function convertObjectToLowerCase(obj) {
    if (typeof obj !== 'object' || obj === null) {
        return obj;
      }
  
    const converted = {};
    for (const key in obj) {
        const convertedKey = key.toLowerCase();
        const value = obj[key];
        const convertedValue = convertObjectToLowerCase(value);
        converted[convertedKey] = convertedValue;
      }
  
    return converted;
  }

class commercial {

    async getTicket(req, res, next) {
        try {

            const newObject = convertObjectToLowerCase(req.body);
            const output = await loginMssql.getTicket(newObject, res);
            jwt.sign(output.recordset[0], secretKey, { expiresIn: 18000000 }, function (err, token) {
                if (err) {
                    res.json(err.message);
                }
                res.json(token);

            })
            //res.send(output.recordset);
        }
        catch (error) {
            next(error)
        }
    }


    async isTicketValid(req, res, next) {
        try {

            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                res.json({"status":"True"}); // bar
            });
            //res.send(output.recordset);
        }
        catch (error) {
            next(error)
        }
    }



    async matchMssql(req, res, next) {
        try {

            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await matchMssql.commercialmatch(newObject, res, decodedObj);
            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }



    async commercialFullCreditMssql(req, res, next) {
        try {
            
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await commercialFullCreditMssql.commercialfullCredit(newObject, res, decodedObj);

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }



    async commercialFullCreditBinaryMssql(req, res, next) {
        try {
            
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await commercialFullCreditBinaryMssql.commercialfullCreditBinary(newObject, res, decodedObj);

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }



    async commercialBasicReportMssql(req, res, next) {
        try {
            
            const newObject = convertObjectToLowerCase(req.body);
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await commercialBasicReportMssql.commercialBasicReport(newObject, res, decodedObj);

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }



    async commercialBasicReportBinaryMssql(req, res, next) {
        try {
            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            const output = await commercialBasicReportBinaryMssql.commercialBasicReportBinary(newObject, res, decodedObj);

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }


     


    async reports(req, res, next) {
        try {
            const newObject = convertObjectToLowerCase(req.body);
            let output = {};
         

            jwt.verify(newObject.dataticket, secretKey, function (err, decoded) {
                if (err) {
                    res.json(err.message);
                }

                decodedObj = decoded; // bar
            });

            if(newObject.productid == 46) {
            output = await commercialBasicReportMssql.commercialBasicReport(newObject, res, decodedObj);
            
            }
            else if(newObject.productid == 47) {
                output = await commercialFullCreditMssql.commercialfullCredit(newObject, res, decodedObj);
                
            }
            else  {
               output={Error:"You entered a wrong productID"}
                
            }

            res.json(output);
        }
        catch (error) {
            next(error)
        }
    }


}
module.exports = new commercial();