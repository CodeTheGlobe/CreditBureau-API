'use strict';
var express = require('express');
var router = express.Router();
const allMethods = require("../Services/allMethods");
const allMethods2 = require("../Services/allMethods2");

/* GET home page. */
//router.get('/', function (req, res) {
 //   res.render('index', { title: 'Express' });

//});

router.post('/', allMethods.consumerFullCreditBinaryMssql);


module.exports = router;
